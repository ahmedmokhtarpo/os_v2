"""
Database Manager Module

This module handles all SQLite database operations for tracking scraped listings.
"""

import sqlite3
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any
from pathlib import Path

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Manages SQLite database operations for the scraper."""
    
    def __init__(self, db_path: str):
        """
        Initialize the database manager.
        
        Args:
            db_path: Path to the SQLite database file
        """
        self.db_path = db_path
        self.setup_database()
    
    def setup_database(self):
        """Create the database and tables if they don't exist."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create scraped_posts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scraped_posts (
                    url TEXT PRIMARY KEY,
                    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    title TEXT,
                    price REAL,
                    city TEXT,
                    status TEXT DEFAULT 'scraped'
                )
            """)
            
            # Create upload_log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS upload_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    listing_url TEXT,
                    upload_status TEXT,
                    upload_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    error_message TEXT,
                    waseetjo_listing_id TEXT,
                    FOREIGN KEY (listing_url) REFERENCES scraped_posts (url)
                )
            """)
            
            # Create image_processing_log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS image_processing_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    listing_url TEXT,
                    original_image_path TEXT,
                    processed_image_path TEXT,
                    processing_status TEXT,
                    processing_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (listing_url) REFERENCES scraped_posts (url)
                )
            """)
            
            conn.commit()
            conn.close()
            logger.info(f"Database initialized at {self.db_path}")
            
        except sqlite3.Error as e:
            logger.error(f"Error setting up database: {e}")
            raise
    
    def check_if_scraped(self, url: str) -> bool:
        """
        Check if a listing URL has already been scraped.
        
        Args:
            url: The listing URL to check
            
        Returns:
            True if the URL has been scraped, False otherwise
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM scraped_posts WHERE url = ?", (url,))
            result = cursor.fetchone()
            conn.close()
            return result is not None
        except sqlite3.Error as e:
            logger.error(f"Error checking if URL scraped: {e}")
            return False
    
    def mark_as_scraped(self, url: str, title: str = None, price: float = None, city: str = None):
        """
        Mark a listing URL as scraped in the database.
        
        Args:
            url: The listing URL
            title: Optional listing title
            price: Optional listing price
            city: Optional listing city
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO scraped_posts (url, title, price, city) 
                VALUES (?, ?, ?, ?)
            """, (url, title, price, city))
            conn.commit()
            conn.close()
            logger.debug(f"Marked as scraped: {url}")
        except sqlite3.Error as e:
            logger.error(f"Error marking URL as scraped: {e}")
    
    def get_scraped_listings(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get all scraped listings from the database.
        
        Args:
            limit: Optional limit on number of results
            
        Returns:
            List of dictionaries containing listing data
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Enable column access by name
            cursor = conn.cursor()
            
            query = "SELECT * FROM scraped_posts ORDER BY scraped_at DESC"
            if limit:
                query += f" LIMIT {limit}"
            
            cursor.execute(query)
            results = [dict(row) for row in cursor.fetchall()]
            conn.close()
            return results
        except sqlite3.Error as e:
            logger.error(f"Error getting scraped listings: {e}")
            return []
    
    def log_upload_attempt(self, listing_url: str, status: str, error_message: str = None, 
                          waseetjo_listing_id: str = None):
        """
        Log an upload attempt to Waseetjo.
        
        Args:
            listing_url: The original listing URL
            status: Upload status ('success', 'failed', 'pending')
            error_message: Optional error message if upload failed
            waseetjo_listing_id: Optional Waseetjo listing ID if upload succeeded
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO upload_log (listing_url, upload_status, error_message, waseetjo_listing_id)
                VALUES (?, ?, ?, ?)
            """, (listing_url, status, error_message, waseetjo_listing_id))
            conn.commit()
            conn.close()
            logger.info(f"Logged upload attempt for {listing_url}: {status}")
        except sqlite3.Error as e:
            logger.error(f"Error logging upload attempt: {e}")
    
    def log_image_processing(self, listing_url: str, original_path: str, 
                           processed_path: str = None, status: str = "processed"):
        """
        Log image processing activity.
        
        Args:
            listing_url: The original listing URL
            original_path: Path to the original image
            processed_path: Path to the processed image
            status: Processing status ('processed', 'failed', 'skipped')
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO image_processing_log 
                (listing_url, original_image_path, processed_image_path, processing_status)
                VALUES (?, ?, ?, ?)
            """, (listing_url, original_path, processed_path, status))
            conn.commit()
            conn.close()
            logger.debug(f"Logged image processing for {listing_url}")
        except sqlite3.Error as e:
            logger.error(f"Error logging image processing: {e}")
    
    def get_upload_statistics(self) -> Dict[str, int]:
        """
        Get upload statistics.
        
        Returns:
            Dictionary with upload statistics
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get total scraped
            cursor.execute("SELECT COUNT(*) FROM scraped_posts")
            total_scraped = cursor.fetchone()[0]
            
            # Get upload statistics
            cursor.execute("""
                SELECT upload_status, COUNT(*) 
                FROM upload_log 
                GROUP BY upload_status
            """)
            upload_stats = dict(cursor.fetchall())
            
            conn.close()
            
            return {
                'total_scraped': total_scraped,
                'successful_uploads': upload_stats.get('success', 0),
                'failed_uploads': upload_stats.get('failed', 0),
                'pending_uploads': upload_stats.get('pending', 0)
            }
        except sqlite3.Error as e:
            logger.error(f"Error getting upload statistics: {e}")
            return {}
    
    def cleanup_old_records(self, days: int = 30):
        """
        Clean up old records from the database.
        
        Args:
            days: Number of days to keep records
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Clean up old upload logs
            cursor.execute("""
                DELETE FROM upload_log 
                WHERE upload_timestamp < datetime('now', '-{} days')
            """.format(days))
            
            # Clean up old image processing logs
            cursor.execute("""
                DELETE FROM image_processing_log 
                WHERE processing_timestamp < datetime('now', '-{} days')
            """.format(days))
            
            deleted_uploads = cursor.rowcount
            conn.commit()
            conn.close()
            
            logger.info(f"Cleaned up {deleted_uploads} old records")
        except sqlite3.Error as e:
            logger.error(f"Error cleaning up old records: {e}")
    
    def close(self):
        """Close any open database connections."""
        # This implementation doesn't maintain persistent connections,
        # so no cleanup is needed
        pass

