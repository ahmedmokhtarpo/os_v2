"""
Main orchestration script for the OpenSooq scraper project.

This script coordinates the entire workflow:
1. Scrape listings from OpenSooq
2. Download images in multiple sizes
3. Process/clean images
4. Upload to Waseetjo
"""

import logging
import json
import sys
import os
from datetime import datetime
from pathlib import Path

# Add src directory to path
sys.path.append(str(Path(__file__).parent / "src"))

import config
from src.database_manager import DatabaseManager
from src.opensooq_scraper import OpenSooqScraper, ImageDownloader
from src.opensooq_api_client import OpenSooqAPIClient
from src.image_processor import ImageProcessor
from src.waseetjo_uploader import WaseetjoUploader

# Setup logging
def setup_logging():
    """Configure logging for the application."""
    config.validate_config()

    logging.basicConfig(
        level=getattr(logging, config.LOG_LEVEL),
        format=config.LOG_FORMAT,
        handlers=[
            logging.FileHandler(config.LOG_FILE),
            logging.StreamHandler(sys.stdout)
        ]
    )

    # Set specific loggers to reduce noise
    logging.getLogger('requests').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)

def scrape_listings(db_manager: DatabaseManager, max_pages: int = None) -> list:
    """
    Scrape listings from OpenSooq.

    Args:
        db_manager: Database manager instance
        max_pages: Maximum pages to scrape (None for config default)

    Returns:
        List of scraped listings
    """
    logger = logging.getLogger(__name__)

    if max_pages is None:
        max_pages = config.MAX_PAGES_TO_SCRAPE

    scraper = OpenSooqScraper(config.OPENSOOQ_BASE_URL, config.USER_AGENT)
    all_listings = []

    current_url = OpenSooqScraper.construct_search_url(
        config.OPENSOOQ_START_CATEGORY_URL,
        page=1,
        sort_recent=True
    )

    pages_scraped = 0

    logger.info(f"Starting to scrape up to {max_pages} pages from OpenSooq")

    while pages_scraped < max_pages and current_url:
        logger.info(f"Scraping page {pages_scraped + 1}")

        # Fetch HTML content
        html_content = scraper.fetch_html(current_url, config.REQUEST_TIMEOUT_SECONDS)
        if not html_content:
            logger.error("Failed to fetch page content. Stopping scrape.")
            break

        try:
            fetch_time = datetime.now()

            # Parse listings from the page
            listings_on_page = scraper.parse_listings(html_content, fetch_time)
            logger.info(f"Parsed {len(listings_on_page)} listings from this page")

            new_listings_count = 0

            for listing in listings_on_page:
                listing_url = listing.get("url")
                if not listing_url:
                    continue

                # Check if already scraped
                if db_manager.check_if_scraped(listing_url):
                    logger.debug(f"Skipping already scraped: {listing_url}")
                    continue

                # Fetch detailed information
                logger.info(f"Fetching details for: {listing_url}")
                detail_html = scraper.fetch_html(listing_url, config.REQUEST_TIMEOUT_SECONDS)

                if not detail_html:
                    logger.warning(f"Failed to fetch detail page: {listing_url}")
                    continue

                # Parse detailed information
                detail_info = scraper.parse_listing_details(detail_html, fetch_time)
                logger.info(f"Parsed details, found {len(detail_info.get('image_urls', []))} image URLs")

                # Merge summary and detail info
                merged_listing = {**listing, **detail_info}
                all_listings.append(merged_listing)

                # Mark as scraped in database
                db_manager.mark_as_scraped(
                    listing_url,
                    merged_listing.get('title'),
                    merged_listing.get('price_value'),
                    merged_listing.get('city')
                )

                new_listings_count += 1

            logger.info(f"Added {new_listings_count} new listings from this page")

            # Get next page URL
            pagination_info = scraper.get_pagination_info(html_content)
            current_url = pagination_info.get('next_page_url')

            pages_scraped += 1

            if current_url:
                logger.info(f"Next page URL: {current_url}")
                if pages_scraped < max_pages:
                    import time
                    time.sleep(config.REQUEST_DELAY_SECONDS)
            else:
                logger.info("No next page found")
                break

        except Exception as e:
            logger.error(f"Error parsing page {current_url}: {e}")
            break

    logger.info(f"Scraping finished. Total pages: {pages_scraped}, Total listings: {len(all_listings)}")
    return all_listings

def download_images(listings: list) -> list:
    """
    Download images for all listings in multiple sizes.

    Args:
        listings: List of listing dictionaries

    Returns:
        Updated listings with download paths
    """
    logger = logging.getLogger(__name__)

    downloader = ImageDownloader(config.USER_AGENT, config.REQUEST_TIMEOUT_SECONDS)

    download_dirs = {
        'large': str(config.IMAGES_LARGE_DIR),
        'medium': str(config.IMAGES_MEDIUM_DIR),
        'small': str(config.IMAGES_SMALL_DIR)
    }

    logger.info("Starting image downloads")
    updated_listings, download_log = downloader.download_images_multiple_sizes(listings, download_dirs)

    # Save download log
    try:
        with open(config.DOWNLOAD_LOG, 'w', encoding='utf-8') as f:
            json.dump(download_log, f, indent=2, ensure_ascii=False)
        logger.info(f"Download log saved to: {config.DOWNLOAD_LOG}")
    except Exception as e:
        logger.error(f"Error saving download log: {e}")

    return updated_listings

def process_images(listings: list) -> list:
    """
    Process/clean images using region detection.

    Args:
        listings: List of listing dictionaries with downloaded images

    Returns:
        Updated listings with processed image paths
    """
    logger = logging.getLogger(__name__)

    processor = ImageProcessor(
        config.REGION_DETECTOR_THRESHOLD,
        config.REGION_DETECTOR_MIN_AREA,
        config.REGION_DETECTOR_TOP_K
    )

    logger.info("Starting image processing")
    result = processor.process_multiple_listings(listings, str(config.IMAGES_CLEANED_DIR))

    # Save processing log
    try:
        with open(config.WATERMARK_LOG, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        logger.info(f"Processing log saved to: {config.WATERMARK_LOG}")
    except Exception as e:
        logger.error(f"Error saving processing log: {e}")

    return listings

def get_phone_numbers(listings: list, api_client: OpenSooqAPIClient) -> dict:
    """
    Get phone numbers for listings using OpenSooq API.

    Args:
        listings: List of listing dictionaries
        api_client: OpenSooq API client instance

    Returns:
        Dictionary mapping listing URLs to phone numbers
    """
    logger = logging.getLogger(__name__)

    phone_numbers = {}

    if not config.OPENSOOQ_AUTH_TOKEN:
        logger.warning("No OpenSooq auth token provided, skipping phone number extraction")
        return phone_numbers

    logger.info("Starting phone number extraction")

    for i, listing in enumerate(listings):
        listing_url = listing.get('url', '')
        listing_title = listing.get('title', 'Unknown')[:50]

        # Extract listing ID from URL
        listing_id = listing_url.split('/')[-1] if listing_url else ''

        if not listing_id:
            logger.warning(f"Could not extract listing ID from URL: {listing_url}")
            continue

        logger.info(f"Getting phone number for listing {i+1}/{len(listings)}: {listing_title}")

        try:
            result = api_client.get_phone_from_listing_id(listing_id)

            if result.get('success') and result.get('phone_number'):
                phone_numbers[listing_url] = result['phone_number']
                logger.info(f"Got phone number for listing: {listing_id}")
            else:
                logger.warning(f"Could not get phone number for listing {listing_id}: {result.get('error', 'Unknown error')}")

        except Exception as e:
            logger.error(f"Error getting phone number for listing {listing_id}: {e}")

        # Add delay between API calls
        import time
        time.sleep(1)

    logger.info(f"Phone number extraction completed. Got {len(phone_numbers)} phone numbers")
    return phone_numbers

def upload_to_waseetjo(listings: list, phone_numbers: dict, db_manager: DatabaseManager) -> dict:
    """
    Upload listings to Waseetjo.

    Args:
        listings: List of listing dictionaries
        phone_numbers: Dictionary mapping listing URLs to phone numbers
        db_manager: Database manager instance

    Returns:
        Dictionary with upload results
    """
    logger = logging.getLogger(__name__)

    uploader = WaseetjoUploader(
        config.WASEETJO_SITE_URL,
        config.WASEETJO_API_USERNAME,
        config.WASEETJO_API_PASSWORD,
        config.WASEETJO_FORM_USERNAME,
        config.WASEETJO_FORM_PASSWORD
    )

    logger.info("Starting upload to Waseetjo")
    result = uploader.upload_multiple_listings(listings, phone_numbers)

    # Log upload attempts to database
    for upload_result in result['results']:
        status = upload_result.get('status')
        error_message = upload_result.get('reason')
        waseetjo_id = upload_result.get('waseetjo_listing_id')

        db_manager.log_upload_attempt(
            upload_result['listing_url'],
            status,
            error_message,
            waseetjo_id
        )

    return result

def save_scraped_data(listings: list):
    """Save scraped data to JSON file."""
    logger = logging.getLogger(__name__)

    try:
        with open(config.SCRAPED_DATA_JSON, 'w', encoding='utf-8') as f:
            json.dump(listings, f, indent=2, ensure_ascii=False, default=str)
        logger.info(f"Scraped data saved to: {config.SCRAPED_DATA_JSON}")
    except Exception as e:
        logger.error(f"Error saving scraped data: {e}")

def main():
    """Main function that orchestrates the entire workflow."""
    setup_logging()
    logger = logging.getLogger(__name__)

    logger.info("Starting OpenSooq scraper project")
    logger.info(f"Configuration: {config.MAX_PAGES_TO_SCRAPE} pages, {config.REQUEST_DELAY_SECONDS}s delay")

    try:
        # Initialize database
        db_manager = DatabaseManager(config.DB_PATH)

        # Step 1: Scrape listings
        logger.info("=== STEP 1: SCRAPING LISTINGS ===")
        listings = scrape_listings(db_manager)

        if not listings:
            logger.warning("No new listings found. Exiting.")
            return

        # Save scraped data
        save_scraped_data(listings)

        # Step 2: Download images
        logger.info("=== STEP 2: DOWNLOADING IMAGES ===")
        listings = download_images(listings)

        # Step 3: Process images
        logger.info("=== STEP 3: PROCESSING IMAGES ===")
        listings = process_images(listings)

        # Step 4: Get phone numbers (if API token available)
        logger.info("=== STEP 4: GETTING PHONE NUMBERS ===")
        phone_numbers = {}
        if config.OPENSOOQ_AUTH_TOKEN:
            api_client = OpenSooqAPIClient(config.OPENSOOQ_AUTH_TOKEN, config.OPENSOOQ_COUNTRY)
            phone_numbers = get_phone_numbers(listings, api_client)
        else:
            logger.warning("Skipping phone number extraction (no auth token)")

        # Step 5: Upload to Waseetjo
        logger.info("=== STEP 5: UPLOADING TO WASEETJO ===")
        upload_result = upload_to_waseetjo(listings, phone_numbers, db_manager)

        # Print summary
        logger.info("=== SUMMARY ===")
        logger.info(f"Total listings processed: {len(listings)}")
        logger.info(f"Phone numbers obtained: {len(phone_numbers)}")
        logger.info(f"Successful uploads: {upload_result['successful_uploads']}")
        logger.info(f"Failed uploads: {upload_result['failed_uploads']}")

        # Print database statistics
        stats = db_manager.get_upload_statistics()
        logger.info(f"Database stats: {stats}")

        logger.info("OpenSooq scraper project completed successfully")

    except Exception as e:
        logger.error(f"Error in main workflow: {e}")
        raise
    finally:
        # Cleanup
        if 'db_manager' in locals():
            db_manager.close()

if __name__ == "__main__":
    main()

