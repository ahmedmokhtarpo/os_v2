"""
OpenSooq API Client Module

This module handles all API interactions with OpenSooq, including:
- Fetching unmasked phone numbers
- Getting view statistics for listings
- HTML parsing for reveal keys
"""

import requests
import logging
import json
from bs4 import BeautifulSoup
from typing import Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)

def extract_data_from_html(html_content: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Extracts the 'reveal_key', 'name', and 'number' from the __NEXT_DATA__ script tag
    within the given HTML content.

    Args:
        html_content: The HTML content to parse.

    Returns:
        A tuple containing (reveal_key, name, number).
        Returns (None, None, None) if the data is not found.
    """
    try:
        # Parse the HTML using BeautifulSoup
        soup = BeautifulSoup(html_content, 'html.parser')

        # Find the script tag with the ID "__NEXT_DATA__"
        next_data_script = soup.find('script', {'id': '__NEXT_DATA__'})

        if not next_data_script:
            logger.error("Script tag with id '__NEXT_DATA__' not found.")
            return None, None, None

        # Extract the JSON string from the script's text content
        json_content = next_data_script.string
        if not json_content:
            logger.error("Script tag '__NEXT_DATA__' has empty content.")
            return None, None, None

        # Parse the JSON string into a Python dictionary
        data = json.loads(json_content)

        # Navigate the dictionary to extract the desired values
        page_props = data.get('props', {}).get('pageProps', {})
        if not page_props:
            logger.error("'props' or 'pageProps' not found in JSON structure.")
            return None, None, None

        data_info = page_props.get('postData', {})
        if not data_info:
            logger.error("'postData' not found in JSON structure.")
            return None, None, None
            
        listing = data_info.get('listing', {})
        reveal_key = listing.get('listing_reveal_phone_key')

        branding_info = listing.get('branding', {})
        name = branding_info.get('name')
        number = branding_info.get('number')

        return reveal_key, name, number

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in '__NEXT_DATA__' script: {e}")
        return None, None, None
    except Exception as e:
        logger.error(f"An unexpected error occurred during HTML parsing: {e}")
        return None, None, None

class OpenSooqAPIClient:
    """
    A client for interacting with OpenSooq APIs.
    """

    def __init__(self, auth_token: str, country: str = "jo"):
        """
        Initialize the OpenSooq API client.

        Args:
            auth_token: The authorization token (Bearer token)
            country: The country code (default: "jo" for Jordan)
        """
        self.auth_token = auth_token
        self.country = country
        # Cache for phone numbers to prevent duplicate API requests
        self.phone_cache = {}
        # Cache for reveal keys to prevent duplicate HTML parsing
        self.reveal_key_cache = {}
        logger.info(f"API client initialized for country: {country}")

    def get_unmasked_phone(self, listing_reveal_phone_key: str) -> Dict[str, Any]:
        """
        Get the unmasked phone number using the OpenSooq reveal API endpoint.

        Args:
            listing_reveal_phone_key: The reveal phone key from the listing response

        Returns:
            The unmasked phone number information if successful, otherwise an error message
        """
        # Check if we already have this phone number in cache
        if listing_reveal_phone_key in self.phone_cache:
            return self.phone_cache[listing_reveal_phone_key]

        # Reveal API endpoint
        url = "https://my.opensooq.com/api/account/reveal/v3/member-phone"

        # Query parameters
        params = {
            "cSource": "opensooq",
            "cName": "direct_web_open",
            "cMedium": "web_open",
            "abBucket": "7"
        }

        # Headers
        headers = {
            "authority": "my.opensooq.com",
            "accept": "application/json, text/plain, */*",
            "accept-language": "ar",
            "authorization": f"Bearer {self.auth_token}",
            "content-type": "application/json",
            "country": self.country,
            "enforce-language": "ar",
            "origin": "https://my.opensooq.com",
            "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
        }

        # Request body
        data = {"reveal_key": listing_reveal_phone_key, "type": "post"}

        try:
            # Make the POST request
            response = requests.post(url, headers=headers, params=params, json=data)

            if response.status_code == 200:
                try:
                    result = response.json()
                    # Cache the result
                    self.phone_cache[listing_reveal_phone_key] = result
                    return result
                except json.JSONDecodeError as e:
                    error_msg = f"Error parsing JSON: {e}"
                    logger.error(error_msg)
                    return {"error": error_msg, "raw_response": response.text}
            else:
                error_msg = f"Error {response.status_code}: {response.text}"
                logger.error(error_msg)
                return {"error": error_msg, "raw_response": response.text}
        except requests.RequestException as e:
            error_msg = f"Request failed: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}

    def get_views(self, ad_id: str) -> Dict[str, Any]:
        """
        Get information about users who viewed a specific listing.

        Args:
            ad_id: The ID of the listing

        Returns:
            A list of user data dictionaries if successful, otherwise an error message
        """
        logger.info(f"Fetching views for ad ID: {ad_id}")

        # API endpoint
        url = f"https://api.opensooq.com/v2.1/post-stats/{ad_id}/lead-users"
        params = {
            "types": "views",
            "cSource": "opensooq",
            "cName": "direct_web_open",
            "cMedium": "web_open",
            "abBucket": "10"
        }

        headers = {
            "authority": "api.opensooq.com",
            "accept": "application/json, text/plain, */*",
            "accept-language": "ar",
            "authorization": f"Bearer {self.auth_token}",
            "country": self.country,
            "source": "desktop",
            "referer": "https://my.opensooq.com/",
            "enforce-language": "ar",
            "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
        }

        try:
            response = requests.get(url, headers=headers, params=params)

            if response.status_code == 200:
                try:
                    data = response.json()
                    all_users = []

                    # Track processed member IDs to avoid duplicate API calls within the same request
                    processed_member_ids = set()

                    for user in data.get('views', []):
                        member = user.get('member', {})
                        member_id = member.get('id')

                        if not member_id:
                            logger.warning(f"Member ID not found in user data: {user}")
                            continue

                        # Skip if we've already processed this member in this batch
                        if member_id in processed_member_ids:
                            continue

                        processed_member_ids.add(member_id)

                        try:
                            # Get reveal key - check cache first
                            reveal_key = None
                            if member_id in self.reveal_key_cache:
                                reveal_key = self.reveal_key_cache[member_id]
                            else:
                                # Get member profile page
                                profile_url = f"https://{self.country}.opensooq.com/ar/mid/{member_id}"
                                logger.info(f"Fetching profile page: {profile_url}")

                                try:
                                    profile_response = requests.get(profile_url)

                                    if profile_response.status_code == 200:
                                        # Extract reveal key from profile page
                                        reveal_key, _, _ = extract_data_from_html(profile_response.text)

                                        # Cache the reveal key
                                        if reveal_key:
                                            self.reveal_key_cache[member_id] = reveal_key
                                        else:
                                            logger.warning(f"Could not extract reveal key for member ID: {member_id}")
                                    else:
                                        logger.error(f"Error fetching profile page: {profile_response.status_code}")
                                except requests.RequestException as e:
                                    logger.error(f"Request failed for profile page: {str(e)}")

                            # Get phone number if reveal key was found
                            phone = None
                            if reveal_key:
                                phone_data = self.get_unmasked_phone(reveal_key)
                                if isinstance(phone_data, dict) and 'error' not in phone_data:
                                    phone = phone_data.get('whatsapp_phone_number')
                                else:
                                    logger.warning(f"Could not get phone for member ID: {member_id}, reveal key: {reveal_key}")
                                    if isinstance(phone_data, dict) and 'error' in phone_data:
                                        logger.warning(f"Error: {phone_data['error']}")

                            # Create user data dictionary
                            lead_user_data = {
                                "date": user.get('date'),
                                "id": member_id,
                                "gender": member.get("gender"),
                                "fullName": member.get("full_name"),
                                "memberLink": member.get("memberLink"),
                                "birthday": member.get("birthday"),
                                "phone": phone
                            }

                            all_users.append(lead_user_data)

                        except Exception as e:
                            logger.error(f"Error processing member ID {member_id}: {str(e)}")

                    return {"views": all_users}

                except json.JSONDecodeError as e:
                    error_msg = f"Error parsing JSON: {str(e)}"
                    logger.error(error_msg)
                    return {"error": error_msg, "raw_response": response.text}
            else:
                error_msg = f"API error: {response.status_code} - {response.text}"
                logger.error(error_msg)
                return {"error": error_msg, "raw_response": response.text}

        except requests.RequestException as e:
            error_msg = f"Request failed: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(error_msg)
            return {"error": error_msg}

    def get_phone_from_listing_id(self, listing_id: str) -> Dict[str, Any]:
        """
        Get phone number from listing ID by first extracting reveal key from profile page.

        Args:
            listing_id: The listing ID

        Returns:
            Contains phone number and status information
        """
        try:
            # Check if we already have the reveal key cached
            reveal_key = None
            if listing_id in self.reveal_key_cache:
                reveal_key = self.reveal_key_cache[listing_id]
                logger.info(f"Using cached reveal key for listing ID: {listing_id}")
            else:
                # Get listing profile page to extract reveal key
                profile_url = f"https://jo.opensooq.com/ar/search/{listing_id}"
                logger.info(f"Fetching profile page: {profile_url}")

                try:
                    profile_response = requests.get(profile_url)

                    if profile_response.status_code == 200:
                        # Extract reveal key from profile page HTML
                        reveal_key, _, _ = extract_data_from_html(profile_response.text)

                        # Cache the reveal key for future use
                        if reveal_key:
                            self.reveal_key_cache[listing_id] = reveal_key
                            logger.info(f"Extracted and cached reveal key for listing ID: {listing_id}")
                        else:
                            logger.warning(f"Could not extract reveal key for listing ID: {listing_id}")
                            return {
                                "success": False,
                                "error": "Could not extract reveal key from profile page",
                                "listing_id": listing_id
                            }
                    else:
                        error_msg = f"Error fetching profile page: HTTP {profile_response.status_code}"
                        logger.error(error_msg)
                        return {
                            "success": False,
                            "error": error_msg,
                            "listing_id": listing_id
                        }
                except requests.RequestException as e:
                    error_msg = f"Request failed for profile page: {str(e)}"
                    logger.error(error_msg)
                    return {
                        "success": False,
                        "error": error_msg,
                        "listing_id": listing_id
                    }

            # Now get the phone number using the reveal key
            if reveal_key:
                phone_data = self.get_unmasked_phone(reveal_key)

                if isinstance(phone_data, dict) and 'error' not in phone_data:
                    phone_number = phone_data.get('whatsapp_phone_number')
                    return {
                        "success": True,
                        "phone_number": phone_number,
                        "listing_id": listing_id,
                        "reveal_key": reveal_key
                    }
                else:
                    error_msg = phone_data.get('error', 'Unknown error getting phone number')
                    logger.error(f"Error getting phone number: {error_msg}")
                    return {
                        "success": False,
                        "error": error_msg,
                        "listing_id": listing_id,
                        "reveal_key": reveal_key
                    }
            else:
                return {
                    "success": False,
                    "error": "No reveal key available",
                    "listing_id": listing_id
                }

        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(error_msg)
            return {
                "success": False,
                "error": error_msg,
                "listing_id": listing_id
            }

