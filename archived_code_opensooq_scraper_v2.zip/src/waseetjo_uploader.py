import random

import requests
from bs4 import BeautifulSoup
import os
import json
import time
import re
import logging
import mimetypes
from urllib.parse import urlparse
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime

# --- Basic Logging Configuration ---
# Configure logging to print info level messages to the console.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class WaseetjoUploader:
    """
    Handles uploading property data and images to waseetjo.com
    """

    def __init__(self, site_url: str, api_username: str, api_password: str,
                 form_username: str, form_password: str):
        """
        Initialize the uploader with authentication credentials.

        Args:
            site_url: Base URL of the Waseetjo website.
            api_username: Username for REST API authentication (image uploads).
            api_password: Application Password for REST API authentication.
            form_username: Username for form-based authentication (login).
            form_password: Password for form-based authentication.
        """
        self.site_url = site_url.rstrip('/')
        self.create_listing_url = f"{self.site_url}/create-listing/"
        self.media_api_url = f"{self.site_url}/wp-json/wp/v2/media"
        self.login_url = f"{self.site_url}/wp-login.php"

        # REST API credentials for image uploads
        self.api_auth = (api_username, api_password)

        # Form login credentials
        self.form_username = form_username
        self.form_password = form_password

        # Session for maintaining login state
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })

        # Taxonomy mappings
        self.taxonomy_maps = self._get_taxonomy_maps()

    def get_taxonomy_maps(self) -> Dict[str, Dict[str, str]]:
        """
        Returns dictionaries for mapping text values to Waseetjo IDs based on provided taxonomy.
        """
        return {
            "status": {
                "للبيع": "32",
                "للايجار": "31"
            },
            "type": {
                "أراضي": "1756",
                "سكني": "1702",
                "شقق فارغة": "74",
                "شقق مفروشة": "809",
                "سوبرماركت": "1765",
                "عمارات": "1758",
                "عيادات": "1766",
                "فلل": "1755",
                "فنادق": "1767",
                "مجمعات": "1761",
                "محلات": "1760",
                "مخازن": "1764",
                "مزارع وشاليهات": "1757",
                "مصانع": "1768",
                "مطاعم وكافيهات": "1763",
                "معارض": "1762",
                "مكاتب": "1759"
            },
            "city": { # Note: This is for reference; form uses a text field 'locality'.
                "عمان": "1688",
                "إربد": "1704",
                "اربد": "1689",
                "الزرقاء": "1690",
                "السلط": "1691",
                "العقبة": "1693",
                "الكرك": "1696",
                "المفرق": "1694",
                "الرمثا": "1699",
                "الطفيله": "1700",
                "الطفيلة": "1739",
                "الغور": "1701"
            },
            "features": {
                # Mapping Arabic keywords from data to the correct Feature ID
                "مكيف": "1622",           # Air Conditioning
                "شرفة": "1627",           # Barbeque (Used for balcony/terrace)
                "بلكونة": "1627",          # Barbeque
                "منطقة شواء": "1627",      # Barbeque
                "جيم": "1641",             # Gym
                "صالة رياضية": "1641",     # Gym
                "غرفة غسيل": "1643",      # Laundry
                "حديقة": "1644",           # Lawn
                "مايكرويف": "1649",       # Microwave
                "ساونا": "1660",           # Sauna
                # Assuming the following IDs from the original script are correct
                "مصعد": "1625",
                "تدفئة": "1623",
                "انتركم": "1624",
                "انترنت": "1666"
            },
            "label": {
                "سنوي": "1687",
                "شهري": "51",
                "يومي": "1686"
            }
        }
    def _get_hidden_login_fields(self) -> Dict[str, str]:
        """Extracts hidden fields from the login form."""
        try:
            response = self.session.get(self.login_url, timeout=30)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            hidden_fields = {
                field.get('name'): field.get('value', '')
                for field in soup.find_all('input', type='hidden') if field.get('name')
            }
            logger.info(f"Found {len(hidden_fields)} hidden fields in login form.")
            return hidden_fields
        except requests.exceptions.RequestException as e:
            logger.error(f"Error getting login form data: {e}")
            return {}

    def login(self) -> bool:
        """
        Logs into the website using form credentials.

        Returns:
            True if login is successful, False otherwise.
        """
        logger.info("Attempting to log in...")
        hidden_fields = self._get_hidden_login_fields()

        login_payload = {
            "log": self.form_username,
            "pwd": self.form_password,
            "wp-submit": "Log In",
            "redirect_to": self.create_listing_url,
            "testcookie": "1",
            **hidden_fields
        }

        try:
            res = self.session.post(self.login_url, data=login_payload, timeout=30, allow_redirects=True)
            res.raise_for_status()

            is_logged_in = (
                "wordpress_logged_in" in self.session.cookies or
                "wp-admin" in res.url or
                "logout" in res.text.lower()
            )

            if is_logged_in:
                logger.info("Login successful!")
                return True
            else:
                soup = BeautifulSoup(res.text, 'html.parser')
                error = soup.find('div', {'id': 'login_error'})
                if error:
                    logger.error(f"Login failed with message: {error.get_text(strip=True)}")
                else:
                    logger.error("Login failed. No success indicators found.")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"An exception occurred during login: {e}")
            return False

    # def _upload_image(self, image_path: str) -> Optional[str]:
    #     """Uploads a single image to the WordPress media library."""
    #     mime_type = mimetypes.guess_type(image_path)[0] or 'application/octet-stream'
    #     file_name = os.path.basename(image_path)

    #     try:
    #         with open(image_path, 'rb') as img_file:
    #             files = {'file': (file_name, img_file, mime_type)}
    #             headers = {'Content-Disposition': f'attachment; filename="{file_name}"'}

    #             res = requests.post(
    #                 self.media_api_url,
    #                 files=files,
    #                 auth=self.api_auth,
    #                 headers=headers,
    #                 timeout=60
    #             )

    #             if res.status_code == 201:
    #                 media_id = str(res.json()['id'])
    #                 logger.info(f"Successfully uploaded {file_name} (ID: {media_id})")
    #                 return media_id
    #             else:
    #                 logger.error(f"Upload failed for {file_name} (Status: {res.status_code}): {res.text}")
    #                 return None
    #     except Exception as e:
    #         logger.error(f"Error uploading {image_path}: {e}")
    #         return None

    # def upload_property_images(self, image_urls: List[str], temp_dir: str = "temp_images") -> List[str]:
    #     """Downloads images from URLs and uploads them to the site."""
    #     os.makedirs(temp_dir, exist_ok=True)
    #     uploaded_ids = []

    #     for i, url in enumerate(image_urls):  # Limit to 10 images
    #         try:
    #             res = requests.get(url, stream=True, timeout=30)
    #             res.raise_for_status()

    #             file_ext = Path(urlparse(url).path).suffix or '.jpg'
    #             save_path = Path(temp_dir) / f"temp_image_{i:02d}{file_ext}"
    #             with open(save_path, 'wb') as f:
    #                 for chunk in res.iter_content(8192):
    #                     f.write(chunk)

    #             media_id = self._upload_image(str(save_path))
    #             if media_id:
    #                 uploaded_ids.append(media_id)

    #             os.remove(save_path)
    #             time.sleep(1)

    #         except Exception as e:
    #             logger.warning(f"Failed to process image {url}: {e}")

    #     logger.info(f"Uploaded {len(uploaded_ids)} images.")
    #     return uploaded_ids

    def upload_image(self, image_path: str) -> Optional[int]:
        """Upload image to WordPress via REST API."""
        media_url = f"{self.site_url}/wp-json/wp/v2/media"
        mime_type = mimetypes.guess_type(image_path)[0] or 'application/octet-stream'

        try:
            with open(image_path, 'rb') as img:
                files = {
                    'file': (os.path.basename(image_path), img, mime_type)
                }
                headers = {
                    'Content-Disposition': f'attachment; filename="{os.path.basename(image_path)}"'
                }

                response = requests.post(media_url, files=files, auth=self.api_auth,
                                       headers=headers, timeout=60)

                if response.status_code == 201:
                    media_id = response.json()['id']
                    logger.info(f"Uploaded: {os.path.basename(image_path)} (ID: {media_id})")
                    return media_id
                else:
                    logger.error(f"Upload failed for {image_path}: {response.status_code} - {response.text}")
                    return None

        except Exception as e:
            logger.error(f"Error uploading {image_path}: {e}")
            return None

    def upload_property_images(self, image_paths: List[str]) -> List[int]:
        """Upload multiple images for a listing."""
        uploaded_ids = []

        for image_path in image_paths:
            if os.path.exists(image_path):
                media_id = self.upload_image(image_path)
                if media_id:
                    uploaded_ids.append(media_id)
                    # Add delay between uploads
                    time.sleep(random.uniform(0, 1))
            else:
                logger.warning(f"Image file not found: {image_path}")

        logger.info(f"Uploaded {len(uploaded_ids)} out of {len(image_paths)} images")
        return uploaded_ids
    def _get_form_nonce(self) -> Optional[Tuple[str, str]]:
        """Extracts the nonce and referer from the create listing page."""
        try:
            res = self.session.get(self.create_listing_url, timeout=30)
            res.raise_for_status()
            soup = BeautifulSoup(res.text, 'html.parser')

            nonce_field = soup.find("input", {"name": "property_nonce"})
            referer_field = soup.find("input", {"name": "_wp_http_referer"})

            if not nonce_field:
                logger.error("Could not find 'property_nonce' on the submission page.")
                return None

            nonce = nonce_field["value"]
            referer = referer_field["value"] if referer_field else self.create_listing_url.replace(self.site_url, '')

            logger.info(f"Extracted nonce: {nonce}")
            return nonce, referer

        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching submission page to get nonce: {e}")
            return None

    def map_property_data(self, scraped_prop: Dict[str, Any], phone_number: Optional[str] = None) -> Dict[str, Any]:
        """
        Converts scraped property data to the required form data format using the new taxonomy.
        """
        title = scraped_prop.get("title", "عقار مميز")
        description = scraped_prop.get("description", "")
        specs = scraped_prop.get("specifications", {})
        sub_category = scraped_prop.get('sub_category_name', "")
        category = scraped_prop.get('category_name', "")

        def get_numeric(text: Any) -> str:
            """Helper to extract the first numeric sequence from a string."""
            if isinstance(text, str):
                match = re.search(r'\d+', text)
                return match.group(0) if match else ""
            return str(text) if text is not None else ""

        # 1. Map Status (للبيع / للايجار)
        status_id = self.taxonomy_maps["status"]["للبيع"]
        if "للايجار" in category:
            status_id = self.taxonomy_maps["status"]["للايجار"]

        # 2. Map Type (شقق, أراضي, فلل, etc.) - Enhanced mapping
        type_id = self.taxonomy_maps["type"]["سكني"]  # Default to 'سكني'

        # Search in both title and sub_category for better matching
        search_text = f"{title} {sub_category}".lower()

        if "أراضي" in sub_category:
            type_id = self.taxonomy_maps["type"]["أراضي"]
        elif "شقق" in sub_category:
            is_furnished = specs.get("مفروشة؟", "غير مفروشة") == "مفروشة"
            type_id = self.taxonomy_maps["type"]["شقق مفروشة"] if is_furnished else self.taxonomy_maps["type"]["شقق فارغة"]
        elif "فلل" in sub_category or "فيلا" in search_text:
            type_id = self.taxonomy_maps["type"]["فلل"]
        elif "عمارات" in sub_category or "عمارة" in search_text:
            type_id = self.taxonomy_maps["type"]["عمارات"]
        elif "سوبرماركت" in search_text:
            type_id = self.taxonomy_maps["type"]["سوبرماركت"]
        elif "عيادات" in search_text or "عيادة" in search_text:
            type_id = self.taxonomy_maps["type"]["عيادات"]
        elif "فنادق" in search_text or "فندق" in search_text:
            type_id = self.taxonomy_maps["type"]["فنادق"]
        elif "مجمعات" in search_text or "مجمع" in search_text:
            type_id = self.taxonomy_maps["type"]["مجمعات"]
        elif "محلات" in search_text or "محل" in search_text:
            type_id = self.taxonomy_maps["type"]["محلات"]
        elif "مخازن" in search_text or "مخزن" in search_text:
            type_id = self.taxonomy_maps["type"]["مخازن"]
        elif "مزارع" in search_text or "شاليه" in search_text:
            type_id = self.taxonomy_maps["type"]["مزارع وشاليهات"]
        elif "مصانع" in search_text or "مصنع" in search_text:
            type_id = self.taxonomy_maps["type"]["مصانع"]
        elif "مطاعم" in search_text or "كافيه" in search_text or "مطعم" in search_text:
            type_id = self.taxonomy_maps["type"]["مطاعم وكافيهات"]
        elif "معارض" in search_text or "معرض" in search_text:
            type_id = self.taxonomy_maps["type"]["معارض"]
        elif "مكاتب" in search_text or "مكتب" in search_text:
            type_id = self.taxonomy_maps["type"]["مكاتب"]

        # 3. Map Features by searching keywords in all relevant text fields
        main_features = specs.get('المزايا الرئيسية', "")
        additional_features = specs.get('المزايا الإضافية', "")
        features_text = f"{title} {description} {main_features} {additional_features}"

        features_ids = list(set([
            feature_id for keyword, feature_id in self.taxonomy_maps["features"].items() if keyword in features_text
        ]))

        # 4. Determine Price and Label
        price = get_numeric(scraped_prop.get("price_value"))
        label_id = self.taxonomy_maps["label"]["شهري"] # Default to 'monthly'

        # 5. Handle Building Age
        building_age_text = specs.get("عمر البناء", "")
        year_built = ""
        # If the building is new (age in months) or under construction, use the current year.
        if "شهر" in building_age_text or "قيد الإنشاء" in building_age_text:
            year_built = str(datetime.now().year)
        else:
            year_built = get_numeric(building_age_text)

        # 6. Consolidate data for submission
        return {
            "prop_title": title,
            "prop_des": description,
            "prop_type[]": [type_id],
            "prop_status[]": [status_id],
            "prop_labels[]": [label_id],
            "prop_price": price,
            "prop_beds": get_numeric(specs.get("عدد الغرف")),
            "prop_baths": get_numeric(specs.get("عدد الحمامات")),
            "prop_size": get_numeric(specs.get("مساحة البناء") or specs.get("مساحة الأرض")),
            "prop_land_area_prefix": "m²",
            "prop_year_built": year_built,
            "prop_features[]": features_ids,
            "locality": scraped_prop.get("city", ""),
            "neighborhood": scraped_prop.get("neighborhood", "").replace(",", "").strip(),
            "fave_agent_display_option": "author_info",
            "prop_featured": "0",
            "action": "add_property",
            "property_author": "49",
            # Custom Fields
            "d8a7d984d8b7d8a8d982": get_numeric(specs.get("الطابق")), # Floor
            "d8b1d982d985-d8a7d984d987d8a7d8aad981": phone_number or "", # Phone Number
            "d984d988d983d98ad8b4d986-d8a7d984d8b9d982d8a7d8b1": f"https://www.google.com/maps/search/?api=1&query={scraped_prop.get('latitude', '0')},{scraped_prop.get('longitude', '0')}", # Location
        }
    def submit_listing(self, property_data: Dict[str, Any], image_ids: List[str]) -> bool:
        """Submits the final property data to the website."""
        nonce_data = self._get_form_nonce()
        if not nonce_data:
            return False

        property_nonce, wp_http_referer = nonce_data

        form_payload = {
            **property_data,
            "propperty_image_ids[]": image_ids,
            "property_nonce": property_nonce,
            "_wp_http_referer": wp_http_referer
        }

        headers = {
            "Origin": self.site_url,
            "Referer": self.create_listing_url,
        }

        logger.info("Submitting property listing...")
        try:
            res = self.session.post(self.create_listing_url, data=form_payload, headers=headers, timeout=60)
            res.raise_for_status()

            if res.status_code == 200 and ("updated" in res.text or "added" in res.text):
                logger.info("Property submitted successfully!")
                return True
            elif res.status_code == 302 or res.ok:
                 logger.info(f"Property submitted successfully (Status: {res.status_code})")
                 return True
            else:
                logger.error(f"Submission failed with status {res.status_code}.")
                return False
        except requests.exceptions.RequestException as e:
            logger.error(f"An exception occurred during submission: {e}")
            return False



    def upload_multiple_listings(self, listings: List[Dict[str, Any]], phone_numbers: Dict[str, str], max_listings: Optional[int] = None, delay_seconds: int = 10) -> Dict[str, Any]:
        """
        Main orchestrator to process a list of properties. Returns a dictionary with results.
        Removes images after each submission.
        """
        if max_listings:
            listings = listings[:max_listings]
        logger.info(f"Starting to process {len(listings)} listings from memory.")
        upload_results = []
        successful_submissions = 0

        if not self.login():
            logger.critical("Login failed. Cannot proceed with uploads. Exiting.")
            return {
                "successful_count": 0,
                "results": [{'status': 'failure', 'reason': 'Login Failed'}]
            }

        for i, prop in enumerate(listings, 1):
            prop_url = prop.get("url", "")
            prop_title = prop.get("title", "N/A")
            image_paths = prop.get("processed_image_paths", [])

            logger.info(f"--- Processing Listing {i}/{len(listings)}: {prop_title} ---")

            try:
                phone = phone_numbers.get(prop_url)
                if not phone:
                    logger.warning(f"No phone number found for listing: {prop_url}")

                property_data = self.map_property_data(prop, phone_number=phone)
                image_ids = self.upload_property_images(image_paths)

                if self.submit_listing(property_data, image_ids):
                    successful_submissions += 1
                    upload_results.append({'url': prop_url, 'title': prop_title, 'status': 'success'})
                    logger.info(f"Successfully submitted listing: {prop_title}")
                else:
                    upload_results.append({'url': prop_url, 'title': prop_title, 'status': 'failure', 'reason': 'Submission failed'})
                    logger.error(f"Failed to submit listing: {prop_title}")

                # Clean up images after submission (whether successful or not)
                self.cleanup_images(image_paths)

                if i < len(listings):
                    logger.info(f"Waiting {delay_seconds} seconds before next submission...")
                    time.sleep(delay_seconds)

            except Exception as e:
                logger.error(f"An unexpected error occurred while processing listing {i}: {e}")
                upload_results.append({'url': prop_url, 'title': prop_title, 'status': 'failure', 'reason': str(e)})

                # Clean up images even if there was an error
                self.cleanup_images(image_paths)

        logger.info("--- Processing Complete ---")
        logger.info(f"Successfully submitted: {successful_submissions}/{len(listings)}")
        return {
            "successful_count": successful_submissions,
            "results": upload_results
        }

    def cleanup_images(self, image_paths: List[str]) -> None:
        """
        Remove image files from the filesystem after upload.
        """
        if not image_paths:
            return

        removed_count = 0
        for image_path in image_paths:
            try:
                if os.path.exists(image_path):
                    os.remove(image_path)
                    removed_count += 1
                    logger.debug(f"Removed image: {image_path}")
                else:
                    logger.warning(f"Image file not found for removal: {image_path}")
            except OSError as e:
                logger.error(f"Failed to remove image {image_path}: {e}")

        if removed_count > 0:
            logger.info(f"Cleaned up {removed_count} image files")
# --- Usage Example ---
if __name__ == "__main__":
    # --- Configurations ---
    SITE_URL = "https://waseetjo.com"
    JSON_FILE_PATH = "eg_data.txt" # IMPORTANT: Make sure this file is in the same directory

    # REST API Authentication (for image uploads)
    USERNAME_FOR_API = "Ahmad999"
    APP_PASSWORD = "mavzekD7PAk2iYOvo8ANfm7R"

    # Form Login Authentication (for form submissions)
    FORM_LOGIN_USERNAME = "Ahmad999"
    FORM_LOGIN_PASSWORD = "t64bMHBRT7JpapS"

    # --- Create an instance of the uploader ---
    uploader = WaseetjoUploader(
        site_url=SITE_URL,
        api_username=USERNAME_FOR_API,
        api_password=APP_PASSWORD,
        form_username=FORM_LOGIN_USERNAME,
        form_password=FORM_LOGIN_PASSWORD
    )

    # --- Load data and run the process ---
    try:
        with open(JSON_FILE_PATH, 'r', encoding='utf-8') as f:
            # Assuming the JSON file contains a list of property dictionaries
            all_listings = json.load(f)
            # Create a dummy phone number dictionary since it's not in the eg_data.txt
            # In a real scenario, this would be populated with actual phone numbers
            phone_numbers_dict = {prop.get("url"): "0790000000" for prop in all_listings}

            uploader.upload_multiple_listings(
                listings=all_listings,
                phone_numbers=phone_numbers_dict,
                max_listings=3,      # Optional: limit the number of properties
                delay_seconds=15     # Optional: delay between submissions
            )

    except FileNotFoundError:
        logger.critical(f"Fatal: The file {JSON_FILE_PATH} was not found.")
    except json.JSONDecodeError:
        logger.critical(f"Fatal: The file {JSON_FILE_PATH} is not a valid JSON file.")
    except Exception as e:
        logger.critical(f"An unexpected error occurred: {e}")