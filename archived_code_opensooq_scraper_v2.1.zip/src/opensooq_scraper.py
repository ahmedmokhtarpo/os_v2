"""
OpenSooq Scraper Module

This module handles scraping of OpenSooq listings, including:
- HTML fetching and parsing
- Pagination handling
- Image downloading in multiple sizes
- Data extraction and cleaning
"""

import requests
import time
import datetime
import os
import hashlib
import json
import re
import logging
from urllib.parse import urljoin, urlparse, parse_qs, urlencode
from typing import List, Dict, Optional, Tuple
from bs4 import BeautifulSoup
from PIL import Image, UnidentifiedImageError

logger = logging.getLogger(__name__)

class OpenSooqScraper:
    """
    A scraper for OpenSooq.com that handles HTML parsing and data extraction.
    """

    def __init__(self, base_url: str = "https://jo.opensooq.com", user_agent: str = None):
        """
        Initialize the scraper.

        Args:
            base_url: The base URL for OpenSooq (default: Jordan)
            user_agent: Custom user agent string
        """
        self.base_url = base_url
        self.user_agent = user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

    def _clean_text(self, text: str) -> str:
        """Helper to clean text from common Arabic formatting characters."""
        if text:
            # Remove ZWNJ, ZWSP, LTR/RTL marks, and strip whitespace
            cleaned = re.sub(r'[\u200c\u200b\u200e\u200f]', '', text)
            return cleaned.strip()
        return ""

    def _calculate_absolute_datetime(self, posted_date_str: str, fetch_time: datetime.datetime) -> str:
        """
        Calculate the approximate absolute datetime of a post based on its
        relative posted date string (Arabic and English) and the page's fetch time.
        """
        if not posted_date_str:
            return None

        posted_datetime = None
        now = fetch_time

        # Clean the input string first
        posted_date_str_cleaned = self._clean_text(posted_date_str).lower()

        try:
            # Arabic Relative Dates
            if "الآن" in posted_date_str_cleaned or "now" in posted_date_str_cleaned:
                posted_datetime = now
            elif "أمس" in posted_date_str_cleaned or "yesterday" in posted_date_str_cleaned:
                posted_datetime = now - datetime.timedelta(days=1)
            elif "دقيقة" in posted_date_str_cleaned or "دقائق" in posted_date_str_cleaned or "minute" in posted_date_str_cleaned:
                minutes_match = re.search(r'(\d+)\s+(?:دقيقة|دقائق|minute|minutes)', posted_date_str_cleaned)
                if minutes_match:
                    minutes_ago = int(minutes_match.group(1))
                    posted_datetime = now - datetime.timedelta(minutes=minutes_ago)
            elif "ساعة" in posted_date_str_cleaned or "ساعات" in posted_date_str_cleaned or "hour" in posted_date_str_cleaned:
                hours_match = re.search(r'(\d+)\s+(?:ساعة|ساعات|hour|hours)', posted_date_str_cleaned)
                if hours_match:
                    hours_ago = int(hours_match.group(1))
                    posted_datetime = now - datetime.timedelta(hours=hours_ago)
            elif "يوم" in posted_date_str_cleaned or "أيام" in posted_date_str_cleaned or "day" in posted_date_str_cleaned:
                days_match = re.search(r'(\d+)\s+(?:يوم|أيام|day|days)', posted_date_str_cleaned)
                if days_match:
                    days_ago = int(days_match.group(1))
                    posted_datetime = now - datetime.timedelta(days=days_ago)
            # Absolute Date format "DD-MM-YYYY"
            elif re.match(r'\d{1,2}-\d{1,2}-\d{4}', posted_date_str_cleaned):
                posted_datetime = datetime.datetime.strptime(posted_date_str_cleaned, '%d-%m-%Y').replace(
                    hour=now.hour, minute=now.minute, second=now.second, microsecond=now.microsecond, tzinfo=datetime.timezone.utc
                )
            # Absolute Date format "Month DD" (e.g., "May 29") - assumes current year
            elif re.match(r'[a-zA-Z]+\s+\d{1,2}', posted_date_str_cleaned):
                try:
                    # Attempt to parse with current year
                    date_with_year = f"{posted_date_str_cleaned} {now.year}"
                    posted_datetime = datetime.datetime.strptime(date_with_year, '%b %d %Y').replace(
                        hour=now.hour, minute=now.minute, second=now.second, microsecond=now.microsecond, tzinfo=datetime.timezone.utc
                    )
                    # If parsed date is in the future, assume it was last year
                    if posted_datetime > now:
                        posted_datetime = posted_datetime.replace(year=now.year - 1)
                except ValueError:
                    pass  # Ignore if format doesn't match

        except Exception as e:
            logger.error(f"Error parsing date string '{posted_date_str}': {e}")
            return None

        return posted_datetime.isoformat() if posted_datetime else None

    def _get_high_res_image_url(self, preview_url: str) -> str:
        """
        Convert a preview image URL to the highest quality version available.
        """
        if not preview_url or not isinstance(preview_url, str):
            return None

        # Ensure it's a full URL before processing
        if not preview_url.startswith("http"):
            # Assuming a base URL for images if it's a relative path
            preview_url = urljoin("https://opensooq-images.os-cdn.com/", preview_url)

        high_res_url = preview_url

        # Dictionary of resolution patterns to replace with highest quality
        resolution_patterns = {
            "previews/640x480/": "previews/2048x0/",
            "previews/0x720/": "previews/2048x0/",
            "previews/0x240/": "previews/2048x0/",
            "previews/320x240/": "previews/2048x0/",
            "previews/480x360/": "previews/2048x0/",
            "previews/800x600/": "previews/2048x0/",
            "previews/700x0/": "previews/2048x0/", # Added for the new format
        }

        # Apply resolution upgrades
        for low_res, high_res in resolution_patterns.items():
            if low_res in high_res_url:
                high_res_url = high_res_url.replace(low_res, high_res)
                break

        # Handle thumbnail patterns
        if "/thumbs/" in high_res_url:
            high_res_url = high_res_url.replace("/thumbs/", "/previews/0x1080/")

        # Handle small image patterns
        if "/small/" in high_res_url:
            high_res_url = high_res_url.replace("/small/", "/previews/0x1080/")

        # Remove .webp extension if present, as it's a format conversion, not part of the base image URI
        if high_res_url.endswith(".webp"):
            high_res_url = high_res_url[:-len(".webp")]

        return high_res_url

    def fetch_html(self, url: str, timeout: int = 60) -> Optional[str]:
        """
        Fetch HTML content from a URL with error handling.

        Args:
            url: The URL to fetch
            timeout: Request timeout in seconds

        Returns:
            HTML content as string, or None if failed
        """
        headers = {"User-Agent": self.user_agent}
        logger.info(f"Fetching HTML: {url}")

        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            response.raise_for_status()
            logger.debug(f"Status Code: {response.status_code}")
            return response.text
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching {url}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error during fetch: {e}")
            return None

    def parse_listings(self, html_content: str, fetch_time: datetime.datetime) -> List[Dict]:
        """
        Parse listing summaries from a search results page.

        Args:
            html_content: The HTML content to parse
            fetch_time: The time the page HTML was fetched

        Returns:
            A list of dictionaries, each representing a listing summary
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        listings = []

        listing_elements = soup.find_all('div', class_=lambda c: c and 'postLi' in c and 'mb-16' in c)
        if not listing_elements:
            listing_elements = soup.find_all('a', class_='postListItemData')  # Fallback

        logger.info(f"Found {len(listing_elements)} potential listing elements")

        for item in listing_elements:
            listing = {}
            link_tag = item.find('a', class_='postListItemData') if item.name == 'div' else item
            if not link_tag:
                continue

            listing['url'] = urljoin(self.base_url, link_tag.get('href', ''))
            if not listing['url'] or not listing['url'].startswith('http'):
                continue

            title_tag = link_tag.find('h2', class_='trimTwoLines')
            listing['title'] = self._clean_text(title_tag.text) if title_tag else None

            img_tag = link_tag.find('img', class_='radius-8')
            preview_image_url = None
            if img_tag:
                preview_image_url = img_tag.get('data-src') or img_tag.get('src')
                if preview_image_url and not preview_image_url.startswith('http'):
                    preview_image_url = urljoin(self.base_url, preview_image_url)

            listing['preview_image_url'] = preview_image_url
            listing['high_res_image_url'] = self._get_high_res_image_url(preview_image_url)

            date_span = link_tag.find('span', class_='postDate')
            listing['posted_date_text'] = self._clean_text(date_span.text) if date_span else None
            listing['posted_datetime'] = self._calculate_absolute_datetime(listing['posted_date_text'], fetch_time)

            price_div = link_tag.find('div', class_='priceColor')
            listing['price_text'] = None
            listing['price_value'] = None
            if price_div:
                price_text_raw = self._clean_text(price_div.text)
                listing['price_text'] = price_text_raw
                price_match = re.search(r'[\d,.]+', price_text_raw)
                if price_match:
                    try:
                        price_str = price_match.group(0).replace(',', '')
                        listing['price_value'] = float(price_str)
                    except ValueError:
                        pass

            location_div = link_tag.find('div', class_='darkGrayColor')
            listing['city'] = None
            listing['neighborhood'] = None
            if location_div:
                location_parts = [self._clean_text(part) for part in location_div.get_text(separator='<!-- -->').split('<!-- -->') if self._clean_text(part)]
                listing['city'] = location_parts[0] if location_parts else None
                listing['neighborhood'] = location_parts[1] if len(location_parts) > 1 else None

            details_p = link_tag.find('p', class_=lambda c: c and 'flexSpaceBetween' in c and 'gap-10' in c)
            listing['details'] = []
            if details_p:
                details_text = self._clean_text(details_p.text)
                listing['details'] = [self._clean_text(d) for d in re.split(r'\s*,\s*', details_text) if self._clean_text(d)]

            listing['is_vip'] = bool(link_tag.find('svg', {'data-name': 'iconVip'}))
            listing['is_turbo'] = bool(link_tag.find('svg', {'data-name': 'iconTurbo'}))
            listing['has_video'] = bool(link_tag.find('svg', {'data-name': 'IconVideo'}))
            listing['photo_count'] = None

            media_count_span = link_tag.find('span', class_='postListItemMedia', string=re.compile(r'\d+'))
            if media_count_span:
                count_match = re.search(r'(\d+)', media_count_span.text)
                if count_match:
                    try:
                        listing['photo_count'] = int(count_match.group(1))
                    except ValueError:
                        pass

            # Add listing only if essential info is present
            if listing.get('url') and listing.get('title') and listing.get('high_res_image_url'):
                listings.append(listing)

        logger.info(f"Successfully parsed {len(listings)} listings")
        return listings

    def parse_listing_details(self, html_content: str, fetch_time: datetime.datetime) -> Dict:
        """
        Parse detailed information from a single listing page using __NEXT_DATA__.

        Args:
            html_content: The HTML content to parse
            fetch_time: The exact time the page was fetched

        Returns:
            A dictionary containing all extracted details from the listing page
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        details = {}

        next_data_script = soup.find('script', {'id': '__NEXT_DATA__'})
        if not next_data_script:
            logger.error("__NEXT_DATA__ script tag not found.")
            return details

        try:
            data = json.loads(next_data_script.string)
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding __NEXT_DATA__ JSON: {e}")
            return details
        # Navigate to relevant data within the JSON
        post_data = None
        if 'props' in data and 'pageProps' in data['props']:
            page_props = data['props']['pageProps']
            # Prioritize the most common path for post data based on the provided HTML
            if 'postData' in page_props and 'listing' in page_props['postData']:
                post_data = page_props['postData']['listing']
            elif 'post' in page_props:
                post_data = page_props['post']
            elif 'initialProps' in page_props and 'pageProps' in page_props['initialProps'] and 'post' in page_props['initialProps']['pageProps']:
                post_data = page_props['initialProps']['pageProps']['post']
            elif 'dehydratedState' in page_props and 'queries' in page_props['dehydratedState']:
                for query in page_props['dehydratedState']['queries']:
                    if 'queryKey' in query and isinstance(query['queryKey'], list) and 'post' in query['queryKey']:
                        if 'state' in query and 'data' in query['state']:
                            post_data = query['state']['data']
                            break

        # Fallback to recursive search if not found in common paths
        if not post_data:
            def find_key_recursive(obj, key_to_find):
                if isinstance(obj, dict):
                    if key_to_find in obj:
                        return obj[key_to_find]
                    for k, v in obj.items():
                        result = find_key_recursive(v, key_to_find)
                        if result:
                            return result
                elif isinstance(obj, list):
                    for item in obj:
                        result = find_key_recursive(item, key_to_find)
                        if result:
                            return result
                return None

            post_data = find_key_recursive(data, 'listing')
            if not post_data:
                post_data = find_key_recursive(data, 'postData')

        if not post_data:
            logger.warning("Could not find post data within __NEXT_DATA__ structure.")
            # Fallback to existing HTML parsing if JSON data is not found
            return self._parse_listing_details_html_fallback(html_content, fetch_time)

        # Extracting data from JSON
        details["title"] = self._clean_text(post_data.get("title"))
        details["description"] = self._clean_text(post_data.get("masked_description"))

        # Price and Currency
        price_info = post_data.get("price")
        if isinstance(price_info, dict) and "price" in price_info:
            details["price"] = str(price_info["price"])
            if "currencies" in price_info and price_info["currencies"]:
                details["currency"] = self._clean_text(price_info["currencies"][0].get("currency_label"))
        elif price_info is not None:
            details["price"] = str(price_info)
        else:
            details["price"] = None

        details["category_name"] = self._clean_text(post_data.get("category", {}).get("label"))
        details["sub_category_name"] = self._clean_text(post_data.get("sub_category", {}).get("label"))
        details["city"] = self._clean_text(post_data.get("city", {}).get("label"))
        details["neighborhood"] = self._clean_text(post_data.get("neighborhood", {}).get("label"))
        details["posted_datetime"] = post_data.get("publish_date")  # Assuming this is already in a suitable format
        details["views"] = post_data.get("views")
        details["is_vip"] = post_data.get("is_vip")
        details["is_turbo"] = post_data.get("is_turbo")
        details["has_video"] = post_data.get("has_video")
        details["photo_count"] = len(post_data.get("media", [])) # Count images from the media list

        # Images
        image_urls = []
        if "media" in post_data and isinstance(post_data["media"], list):
            for img in post_data["media"]:
                if "uri" in img:
                    # Construct full image URL. Assuming a base URL for images.
                    # This might need adjustment based on how OpenSooq constructs image URLs.
                    full_image_url = urljoin("https://opensooq-images.os-cdn.com/previews/2048x0/", img["uri"]+'.jpg')
                    image_urls.append(self._get_high_res_image_url(full_image_url))
        details["image_urls"] = image_urls

        # Specifications (attributes) - using basic_info from the JSON
        specs = {}
        if "basic_info" in post_data and isinstance(post_data["basic_info"], list):
            for attr in post_data["basic_info"]:
                if "field_label" in attr and "option_label" in attr:
                    specs[self._clean_text(attr["field_label"])] = self._clean_text(attr["option_label"])
                elif "field_label" in attr and "options" in attr and isinstance(attr["options"], list):
                    # Handle multi-select attributes
                    options_list = [self._clean_text(opt["option_label"]) for opt in attr["options"] if "option_label" in opt]
                    if options_list:
                        specs[self._clean_text(attr["field_label"])] = ", ".join(options_list)

        details["specifications"] = specs

        # Location coordinates
        if "post_map" in post_data and "lat" in post_data["post_map"] and "lng" in post_data["post_map"]:
            details["latitude"] = post_data["post_map"]["lat"]
            details["longitude"] = post_data["post_map"]["lng"]

        # Phone reveal logic
        details["phone_number_encrypted"] = post_data.get("masked_local_phone")
        details["phone_reveal_token"] = post_data.get("listing_reveal_phone_key")

        return details

    def _parse_listing_details_html_fallback(self, html_content: str, fetch_time: datetime.datetime) -> Dict:
        """
        Fallback HTML parsing for detailed information from a single listing page.
        This method is used if __NEXT_DATA__ is not found or fails to parse.
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        details = {}

        # Title
        title_tag = soup.find('h1', class_='postViewTitle')
        details['title'] = self._clean_text(title_tag.text) if title_tag else None

        # Price
        price_div = soup.find('div', class_='priceColor')
        if price_div:
            price_text = self._clean_text(price_div.text)
            details['price'] = re.sub(r'[^\d,.]', '', price_text).replace(',', '')

        # Description
        desc_div = soup.find('div', class_='postViewDescription')
        details['description'] = self._clean_text(desc_div.text) if desc_div else ""

        # Specifications
        specs = {}
        spec_sections = soup.find_all('div', class_='postViewSpecifications')
        for section in spec_sections:
            spec_items = section.find_all('div', class_='postViewSpecificationItem')
            for item in spec_items:
                label_span = item.find('span', class_='postViewSpecificationLabel')
                value_span = item.find('span', class_='postViewSpecificationValue')
                if label_span and value_span:
                    label = self._clean_text(label_span.text)
                    value = self._clean_text(value_span.text)
                    if label and value:
                        specs[label] = value

        details['specifications'] = specs

        # Images
        image_urls = []
        image_containers = soup.find_all('div', class_='postViewImageContainer')
        for container in image_containers:
            img_tag = container.find('img')
            if img_tag:
                img_url = img_tag.get('data-src') or img_tag.get('src')
                if img_url:
                    if not img_url.startswith('http'):
                        img_url = urljoin(self.base_url, img_url)
                    high_res_url = self._get_high_res_image_url(img_url)
                    if high_res_url:
                        image_urls.append(high_res_url)

        details['image_urls'] = image_urls

        # Location coordinates
        map_script = soup.find('script', string=re.compile(r'latitude.*longitude'))
        if map_script:
            lat_match = re.search(r'latitude["\\]?\s*:\s*["\\]?([0-9.-]+)', map_script.string)
            lng_match = re.search(r'longitude["\\]?\s*:\s*["\\]?([0-9.-]+)', map_script.string)
            if lat_match and lng_match:
                details['latitude'] = float(lat_match.group(1))
                details['longitude'] = float(lng_match.group(1))

        return details

    def get_pagination_info(self, html_content: str) -> Dict:
        """
        Extract pagination information from search results page.

        Args:
            html_content: The HTML content to parse

        Returns:
            Dictionary with pagination info
        """
        soup = BeautifulSoup(html_content, 'html.parser')
        pagination_info = {
            'next_page_url': None,
            'last_page_number': None
        }

        pagination_div = soup.find('div', id='pagination')
        if pagination_div:
            next_page_arrow = pagination_div.find('a', {'data-id': 'nextPageArrow'})
            if next_page_arrow and 'disabled' not in next_page_arrow.get('class', []) and next_page_arrow.get('href'):
                pagination_info['next_page_url'] = urljoin(self.base_url, next_page_arrow['href'])

            page_links = pagination_div.find_all('a', {'data-id': re.compile(r'page_\d+')})
            max_page = 0
            for link in page_links:
                try:
                    page_num = int(link.text.strip())
                    if page_num > max_page:
                        max_page = page_num
                except (ValueError, AttributeError):
                    continue
            if max_page > 0:
                pagination_info['last_page_number'] = max_page
            else:
                last_page_arrow = pagination_div.find('a', {'data-id': 'lastPageArrow'})
                if last_page_arrow and last_page_arrow.get('href'):
                    parsed_url = urlparse(last_page_arrow['href'])
                    query_params = parse_qs(parsed_url.query)
                    if 'page' in query_params and query_params['page'][0].isdigit():
                        pagination_info['last_page_number'] = int(query_params['page'][0])

        return pagination_info

    @staticmethod
    def construct_search_url(base_category_url: str, search_term: str = None,
                           page: int = 1, sort_recent: bool = False) -> str:
        """
        Construct a search URL for a specific page, optional search term, and sorting.

        Args:
            base_category_url: The starting URL for the category
            search_term: A search term to add
            page: The page number
            sort_recent: Whether to sort by most recent

        Returns:
            The constructed URL
        """
        parsed_url = urlparse(base_category_url)
        query_params = parse_qs(parsed_url.query)

        if search_term:
            query_params['search'] = ['true']
            query_params['term'] = [search_term]
        else:
            query_params.pop('search', None)
            query_params.pop('term', None)

        if page > 1:
            query_params['page'] = [str(page)]
        elif 'page' in query_params:
            del query_params['page']

        if sort_recent:
            query_params['sort_code'] = ['recent']
        elif 'sort_code' in query_params:
            del query_params['sort_code']

        new_query = urlencode(query_params, doseq=True)
        return parsed_url._replace(query=new_query).geturl()

class ImageDownloader:
    """Handles downloading images in multiple sizes."""

    def __init__(self, user_agent: str = None, timeout: int = 60):
        """
        Initialize the image downloader.

        Args:
            user_agent: Custom user agent string
            timeout: Request timeout in seconds
        """
        self.user_agent = user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        self.timeout = timeout

    def convert_image_url_size(self, original_url: str, target_size: str) -> str:
        """
        Convert OpenSooq image URL to different sizes.

        Args:
            original_url: Original image URL
            target_size: Target size ('large', 'medium', 'small')

        Returns:
            Modified URL with the target size
        """
        size_mapping = {
            'large': '2048x0',
            'medium': '0x1080',
            'small': '300x0'
        }

        if target_size not in size_mapping:
            return original_url

        target_size_str = size_mapping[target_size]

        # Replace the size in the URL
        if '/previews/' in original_url:
            pattern = r'/previews/\d+x\d+/'
            replacement = f'/previews/{target_size_str}/'
            return re.sub(pattern, replacement, original_url)

        return original_url

    def download_image_as_jpg(self, url: str, save_path: str) -> Tuple[bool, str]:
        """
        Download an image from a URL and save it as JPG.

        Args:
            url: The image URL
            save_path: Path to save the image

        Returns:
            Tuple of (success, message)
        """
        if not url or not url.startswith("http"):
            return False, "Invalid URL"

        headers = {"User-Agent": self.user_agent}

        try:
            response = requests.get(url, headers=headers, timeout=self.timeout, stream=True)
            response.raise_for_status()

            content_type = response.headers.get("content-type", "").lower()
            if content_type and not content_type.startswith("image/"):
                logger.warning(f"Content-Type ({content_type}) doesn't look like an image, attempting conversion anyway")

            try:
                img = Image.open(response.raw)
                if img.mode in ("RGBA", "P"):
                    img = img.convert("RGB")

                # Ensure directory exists
                os.makedirs(os.path.dirname(save_path), exist_ok=True)
                img.save(save_path, "JPEG", quality=95)
                return True, "Success"

            except UnidentifiedImageError:
                return False, "Cannot identify image file (PIL)"
            except IOError as e:
                return False, f"PIL file error: {e}"

        except requests.exceptions.RequestException as e:
            status_code = e.response.status_code if e.response is not None else None
            return False, f"Request error: {e} (Status: {status_code})"
        except Exception as e:
            return False, f"Unexpected error during download/conversion: {e}"

    def generate_filename_from_url_jpg(self, url: str, listing_url_hash: str,
                                     image_index: int, size_suffix: str = "") -> str:
        """
        Generate a unique filename with .jpg extension from a URL.

        Args:
            url: The image URL
            listing_url_hash: Hash of the listing URL
            image_index: Index of the image
            size_suffix: Size suffix for the filename

        Returns:
            Generated filename
        """
        try:
            parsed_url = urlparse(url)
            path_query = parsed_url.path + ("?" + parsed_url.query if parsed_url.query else "")
            image_hash = hashlib.sha1(path_query.encode("utf-8")).hexdigest()[:8]
            size_part = f"_{size_suffix}" if size_suffix else ""
            return f"{listing_url_hash}_{image_index:02d}_{image_hash}{size_part}.jpg"
        except Exception:
            fallback_hash = hashlib.sha1(url.encode("utf-8")).hexdigest()[:8]
            size_part = f"_{size_suffix}" if size_suffix else ""
            return f"{listing_url_hash}_{image_index:02d}_{fallback_hash}{size_part}.jpg"

    def download_images_multiple_sizes(self, listings: List[Dict], download_dirs: Dict[str, str]) -> List[Dict]:
        """
        Download images in multiple sizes for each listing.

        Args:
            listings: List of listing dictionaries
            download_dirs: Dictionary mapping size names to directory paths

        Returns:
            Updated listings with download paths
        """
        # Create directories
        for dir_path in download_dirs.values():
            os.makedirs(dir_path, exist_ok=True)

        download_log = []
        total_images_attempted = 0
        total_images_succeeded = 0

        logger.info("Starting multi-size image downloads")
        logger.info(f"Download directories: {download_dirs}")

        for i, listing in enumerate(listings):
            listing_url = listing.get("url", f"unknown_listing_{i}")
            listing_title = listing.get("title", "N/A")[:50]
            image_urls = listing.get("image_urls", [])

            listing_url_hash = hashlib.sha1(listing_url.encode("utf-8")).hexdigest()[:10]

            # Initialize paths for different sizes
            listing['downloaded_paths'] = {
                'large': [],
                'small': []
            }

            if not image_urls:
                logger.info(f"Listing {i+1}/{len(listings)} ({listing_title}): No image URLs found")
                continue

            logger.info(f"Listing {i+1}/{len(listings)} ({listing_title}): Found {len(image_urls)} images")

            for img_idx, original_img_url in enumerate(image_urls):
                # Download in three different sizes
                for size_name, download_dir in download_dirs.items():
                    total_images_attempted += 1

                    # Convert URL to appropriate size
                    sized_url = self.convert_image_url_size(original_img_url, size_name)
                    filename = self.generate_filename_from_url_jpg(sized_url, listing_url_hash, img_idx, size_name)
                    save_path = os.path.join(download_dir, filename)

                    log_entry = {
                        "listing_index": i,
                        "listing_url": listing_url,
                        "listing_title": listing_title,
                        "image_index": img_idx,
                        "size": size_name,
                        "original_url": original_img_url,
                        "sized_url": sized_url,
                        "download_status": "Failed",
                        "message": "",
                        "local_path": save_path
                    }

                    logger.debug(f"Downloading {size_name} image {img_idx+1}/{len(image_urls)}: {filename}")
                    success, message = self.download_image_as_jpg(sized_url, save_path)

                    if success:
                        logger.debug("Success")
                        log_entry["download_status"] = "Success"
                        log_entry["message"] = "Image downloaded successfully as JPG"
                        listing['downloaded_paths'][size_name].append(save_path)
                        total_images_succeeded += 1
                    else:
                        logger.warning(f"Failed: {message}")
                        log_entry["message"] = f"Download failed: {message}"
                        if os.path.exists(save_path):
                            try:
                                os.remove(save_path)
                            except OSError as e:
                                logger.warning(f"Could not remove failed download file {save_path}: {e}")

                    download_log.append(log_entry)

        logger.info("Multi-size image downloads finished")
        logger.info(f"Attempted: {total_images_attempted} images")
        logger.info(f"Succeeded: {total_images_succeeded} images")
        logger.info(f"Failed: {total_images_attempted - total_images_succeeded} images")

        return listings, download_log

