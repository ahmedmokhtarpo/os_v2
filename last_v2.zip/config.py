"""
Configuration module for OpenSooq Scraper Project

This module centralizes all configuration parameters including:
- API credentials and endpoints
- File paths and directories
- Scraping parameters
- Database settings
"""

import os
from pathlib import Path

# Base project directory
PROJECT_ROOT = Path(__file__).parent.absolute()

# --- OpenSooq Configuration ---
OPENSOOQ_BASE_URL = "https://jo.opensooq.com"
OPENSOOQ_START_CATEGORY_URL = "https://jo.opensooq.com/ar/property/"

# Scraping parameters
MAX_PAGES_TO_SCRAPE = 2
REQUEST_DELAY_SECONDS = 1
REQUEST_TIMEOUT_SECONDS = 60
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

# Date filtering (None for no limit)
DATE_LIMIT_DAYS = 1  # Set to number of days to limit scraping to recent posts

# --- OpenSooq API Configuration ---
# These should be set via environment variables for security
OPENSOOQ_AUTH_TOKEN = os.getenv("OPENSOOQ_AUTH_TOKEN", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdDAiOjE3NDQ2NzA4NjYsImF1ZCI6ImRlc2t0b3AiLCJzdWIiOjY1MjY0NDc4LCJybmQiOiI5MTAyMjE0IiwiZXhwIjoxNzQ0NjkyNTkwfQ.NGD--kykFGf4KKNRcH_tWxPKz-sd2eJ4QpG4AXgMHXY")
OPENSOOQ_COUNTRY = "jo"  # Jordan

# --- Waseetjo Configuration ---
WASEETJO_SITE_URL = "https://waseetjo.com"
WASEETJO_CREATE_LISTING_URL = f"{WASEETJO_SITE_URL}/create-listing/"

# REST API Authentication (for image uploads)
WASEETJO_API_USERNAME = os.getenv("WASEETJO_API_USERNAME", "Ahmad999")
WASEETJO_API_PASSWORD = os.getenv("WASEETJO_API_PASSWORD", "mavzekD7PAk2iYOvo8ANfm7R")

# Form Login Authentication (for form submissions)
WASEETJO_FORM_USERNAME = os.getenv("WASEETJO_FORM_USERNAME", "Ahmad999")
WASEETJO_FORM_PASSWORD = os.getenv("WASEETJO_FORM_PASSWORD", "t64bMHBRT7JpapS")

# --- Directory Configuration ---
DATA_DIR = PROJECT_ROOT / "data"
LOGS_DIR = PROJECT_ROOT / "logs"
IMAGES_DIR = PROJECT_ROOT / "images"

# Image subdirectories
IMAGES_LARGE_DIR = IMAGES_DIR / "downloaded_large"
IMAGES_MEDIUM_DIR = IMAGES_DIR / "downloaded_medium"
IMAGES_SMALL_DIR = IMAGES_DIR / "downloaded_small"
IMAGES_CLEANED_DIR = IMAGES_DIR / "cleaned"

# --- File Configuration ---
SCRAPED_DATA_JSON = DATA_DIR / "scraped_listings.json"
DOWNLOAD_LOG = DATA_DIR / "download_log.json"
WATERMARK_LOG = DATA_DIR / "watermark_removal_log.json"
TRACKING_DB = DATA_DIR / "scraped_listings.db"

# Log file
LOG_FILE = LOGS_DIR / "app.log"

# --- Database Configuration ---
DB_PATH = str(TRACKING_DB)

# --- Image Processing Configuration ---
# RegionDetector parameters
REGION_DETECTOR_THRESHOLD = 55
REGION_DETECTOR_MIN_AREA = 60
REGION_DETECTOR_TOP_K = 5

# --- Logging Configuration ---
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# --- Waseetjo Taxonomy Mappings ---
WASEETJO_TAXONOMY_MAPS = {
    "status": {
        "للبيع": "32",
        "للايجار": "31"
    },
    "type": {
        "شقق": "74",  # شقق فارغة
        "سكني": "1702",
        "أراضي": "76"  # Adding land type
    },
    "city": {
        "إربد": "1704",
        "اربد": "1689",
        "الرمثا": "1699",
        "الزرقاء": "1690",
        "السلط": "1691",
        "الطفيله": "1700",
        "العقبة": "1693",
        "الغور": "1701",
        "الكرك": "1696",
        "المفرق": "1694",
        "عمان": "1688"  # Adding Amman
    },
    "features": {
        "مكيف": "1622",  # Air Conditioning
        "شرفة": "1627",  # Balcony/Terrace
        "غرفة غسيل": "1643",  # Laundry
        "حديقة": "1644",  # Garden/Lawn
        "مايكرويف": "1649",  # Microwave
        "موقف سيارات": "1655",  # Parking
        "ساونا": "1660",  # Sauna
        "جيم": "1641",  # Gym
        "انترنت": "1666",  # Wi-Fi
        "مصعد": "1625",  # Elevator
        "تدفئة": "1623",  # Heating
        "انتركم": "1624"  # Intercom
    }
}

# --- Validation ---
def validate_config():
    """Validate configuration and create necessary directories."""
    # Create directories if they don't exist
    for directory in [DATA_DIR, LOGS_DIR, IMAGES_DIR, IMAGES_LARGE_DIR,
                     IMAGES_MEDIUM_DIR, IMAGES_SMALL_DIR, IMAGES_CLEANED_DIR]:
        directory.mkdir(parents=True, exist_ok=True)

    # Check for required environment variables
    required_env_vars = []

    if not OPENSOOQ_AUTH_TOKEN:
        required_env_vars.append("OPENSOOQ_AUTH_TOKEN")

    if required_env_vars:
        print(f"Warning: Missing environment variables: {', '.join(required_env_vars)}")
        print("Some functionality may not work without proper authentication.")

    return True

# Initialize configuration
if __name__ == "__main__":
    validate_config()
    print("Configuration validated successfully!")

