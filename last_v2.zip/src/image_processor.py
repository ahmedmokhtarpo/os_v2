"""
Image Processor Module

This module handles image processing tasks, including:
- Region detection and replacement
- Watermark removal (specifically targeting the 'opensooq' logo)
- Image cleaning and enhancement
"""
import cv2
import numpy as np
import logging
import hashlib
import os
from typing import List, Dict, Tuple, Optional, Any
from pathlib import Path

logger = logging.getLogger(__name__)

class RegionDetector:
    """
    A class for detecting significant difference regions between images and replacing them
    with content from a source image (the small image).
    """

    def __init__(self, threshold: int = 20, min_area: int = 50, # Adjusted threshold and min_area
                 max_grouping_distance: int = 80): # Increased max_grouping_distance
        """
        Initialize the RegionDetector.

        Args:
            threshold: Threshold for difference detection (0-255). Lower values detect more differences.
            min_area: Minimum area for a region to be considered. Lower values detect smaller regions.
            max_grouping_distance: Maximum pixel distance between bounding boxes for them to be grouped.
                                   Increased to better capture fragmented logos.
        """
        self.threshold = threshold
        self.min_area = min_area
        self.max_grouping_distance = max_grouping_distance

    def load_and_validate_images(self, large_path: str, small_path: str) -> Tuple[np.ndarray, np.ndarray]:
        """
        Load and validate the two input images (large and small).

        Args:
            large_path: Path to the large image
            small_path: Path to the small image

        Returns:
            Tuple of (large_img, small_img)

        Raises:
            ValueError: If any image cannot be loaded
            FileNotFoundError: If any image file doesn't exist
        """
        # Check if files exist
        for path in [large_path, small_path]:
            if not os.path.exists(path):
                raise FileNotFoundError(f"Image file not found: {path}")

        # Load images
        large_img = cv2.imread(large_path)
        small_img = cv2.imread(small_path)

        # Validate images loaded successfully
        if any(img is None for img in [large_img, small_img]):
            raise ValueError("Could not load one or more images. Check file paths and formats.")

        return large_img, small_img

    def resize_images_to_match(self, large_img: np.ndarray,
                              small_img: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Resize the small image to match the large image dimensions.

        Args:
            large_img: Reference image for dimensions
            small_img: Image to resize

        Returns:
            Tuple of (large_img, small_resized)
        """
        large_h, large_w = large_img.shape[:2]
        small_resized = cv2.resize(small_img, (large_w, large_h))

        return large_img, small_resized

    def calculate_difference_mask(self, large_img: np.ndarray,
                                 small_img: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Calculate the difference mask between large and small images.

        Args:
            large_img: First image for comparison
            small_img: Second image for comparison

        Returns:
            Tuple of (binary mask, difference image)
        """
        # Convert to grayscale
        large_gray = cv2.cvtColor(large_img, cv2.COLOR_BGR2GRAY)
        small_gray = cv2.cvtColor(small_img, cv2.COLOR_BGR2GRAY)

        # Calculate absolute difference
        diff = cv2.absdiff(large_gray, small_gray)

        # Apply Gaussian blur to reduce noise
        diff_blurred = cv2.GaussianBlur(diff, (5, 5), 0)

        # Create binary mask
        _, mask = cv2.threshold(diff_blurred, self.threshold, 255, cv2.THRESH_BINARY)

        # Clean up mask with morphological operations
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        return mask, diff

    def extract_region_features(self, contour: np.ndarray, diff: np.ndarray,
                               mask_shape: Tuple[int, int]) -> Optional[Dict[str, Any]]:
        """
        Extract features from a contour region for importance scoring.

        Args:
            contour: OpenCV contour
            diff: Difference image for intensity calculation
            mask_shape: Shape of the mask for creating region mask

        Returns:
            Dictionary containing region features, or None if area too small
        """
        # Get bounding rectangle
        x, y, w, h = cv2.boundingRect(contour)
        area = cv2.contourArea(contour)

        # Skip if area is too small
        if area < self.min_area:
            return None

        # Calculate geometric properties
        perimeter = cv2.arcLength(contour, True)
        aspect_ratio = w / h if h > 0 else 0
        extent = area / (w * h) if (w * h) > 0 else 0

        # Calculate average difference intensity in this region
        region_mask = np.zeros(mask_shape, dtype=np.uint8)
        cv2.fillPoly(region_mask, [contour], 255)
        avg_diff_intensity = np.mean(diff[region_mask > 0]) if np.any(region_mask > 0) else 0

        # Calculate compactness (lower is more compact/circular)
        compactness = (perimeter * perimeter) / area if area > 0 else float('inf')

        # Calculate importance score
        importance_score = self._calculate_importance_score(
            area, avg_diff_intensity, compactness, extent
        )

        return {
            'contour': contour,
            'bbox': (x, y, w, h),
            'center': (x + w//2, y + h//2),
            'area': area,
            'perimeter': perimeter,
            'aspect_ratio': aspect_ratio,
            'extent': extent,
            'avg_diff_intensity': avg_diff_intensity,
            'compactness': compactness,
            'importance_score': importance_score
        }

    def _calculate_importance_score(self, area: float, avg_diff_intensity: float,
                                   compactness: float, extent: float) -> float:
        """
        Calculate the importance score for a region based on multiple factors.

        Args:
            area: Region area
            avg_diff_intensity: Average difference intensity
            compactness: Shape compactness measure
            extent: Fill ratio of bounding box

        Returns:
            Importance score (higher = more important)
        """
        return (
            area * 0.4 +                           # Size importance
            avg_diff_intensity * 0.3 +             # Difference intensity
            (1 / (compactness + 1)) * 100 * 0.2 +  # Shape regularity
            extent * 50 * 0.1                      # Fill ratio
        )

    def find_difference_regions(self, mask: np.ndarray,
                               diff: np.ndarray) -> List[Dict[str, Any]]:
        """
        Find and analyze all difference regions in the mask.

        Args:
            mask: Binary difference mask
            diff: Difference image for intensity calculations

        Returns:
            List of region dictionaries sorted by importance
        """
        # Find contours
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Extract features for each region
        regions = []
        for i, contour in enumerate(contours):
            features = self.extract_region_features(contour, diff, mask.shape)
            if features is not None:
                features['id'] = i
                regions.append(features)

        # Sort by importance score (though not strictly needed if grouping is primary)
        regions.sort(key=lambda x: x['importance_score'], reverse=True)

        return regions

    def _get_bbox_center(self, bbox: Tuple[int, int, int, int]) -> Tuple[int, int]:
        """Helper to get the center of a bounding box."""
        x, y, w, h = bbox
        return x + w // 2, y + h // 2

    def _distance(self, p1: Tuple[int, int], p2: Tuple[int, int]) -> float:
        """Helper to calculate Euclidean distance between two points."""
        return np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

    def group_nearby_regions(self, regions: List[Dict[str, Any]]) -> List[Tuple[int, int, int, int]]:
        """
        Groups nearby regions into single, larger bounding boxes.

        Args:
            regions: List of individual region dictionaries, each with a 'bbox'.

        Returns:
            List of merged bounding boxes (x, y, w, h).
        """
        if not regions:
            return []

        grouped_bboxes = []

        # Keep track of which regions have been assigned to a group
        assigned = [False] * len(regions)

        for i, current_region in enumerate(regions):
            if assigned[i]:
                continue

            # Start a new group with the current region
            current_bbox = current_region['bbox']
            min_x, min_y, max_x, max_y = current_bbox[0], current_bbox[1], \
                                         current_bbox[0] + current_bbox[2], \
                                         current_bbox[1] + current_bbox[3]

            # This group will expand to include nearby regions
            current_group_members = [i]
            assigned[i] = True

            # Iterate through unassigned regions to find neighbors
            # Use a while loop to re-check as the group expands
            has_new_members = True
            while has_new_members:
                has_new_members = False
                for j, other_region in enumerate(regions):
                    if not assigned[j]:
                        other_bbox = other_region['bbox']
                        # Calculate distance between current group's merged bbox and other region's bbox
                        # A simple way: check if they are "close" to each other based on their borders
                        # or if their centers are within a certain distance.
                        # For logos, often they are small components of a larger visual, so simple overlap
                        # or small distance between bounding box edges is good.

                        # Calculate bounding box of the current group
                        group_current_bbox = (min_x, min_y, max_x - min_x, max_y - min_y)

                        # Check for overlap or proximity
                        x1, y1, w1, h1 = group_current_bbox
                        x2, y2, w2, h2 = other_bbox

                        # Check for overlap
                        overlap = not (x1 + w1 < x2 or x2 + w2 < x1 or y1 + h1 < y2 or y2 + h2 < y1)

                        # Check for proximity if no direct overlap (extend bounding boxes)
                        # Expand both bounding boxes by max_grouping_distance and check for overlap
                        x1_ext, y1_ext = x1 - self.max_grouping_distance, y1 - self.max_grouping_distance
                        w1_ext, h1_ext = w1 + 2 * self.max_grouping_distance, h1 + 2 * self.max_grouping_distance
                        x2_ext, y2_ext = x2 - self.max_grouping_distance, y2 - self.max_grouping_distance
                        w2_ext, h2_ext = w2 + 2 * self.max_grouping_distance, h2 + 2 * self.max_grouping_distance

                        proximate = not (x1_ext + w1_ext < x2_ext or x2_ext + w2_ext < x1_ext or \
                                         y1_ext + h1_ext < y2_ext or y2_ext + h2_ext < y1_ext)

                        if overlap or proximate:
                            # Merge the other_region into the current group
                            min_x = min(min_x, other_bbox[0])
                            min_y = min(min_y, other_bbox[1])
                            max_x = max(max_x, other_bbox[0] + other_bbox[2])
                            max_y = max(max_y, other_bbox[1] + other_bbox[3])

                            assigned[j] = True
                            current_group_members.append(j)
                            has_new_members = True # Keep iterating until no new members are added

            # Add the final merged bounding box for this group
            grouped_bboxes.append((min_x, min_y, max_x - min_x, max_y - min_y))

        return grouped_bboxes


    def blend_region_by_bbox(self, result_img: np.ndarray, source_img: np.ndarray,
                             bbox: Tuple[int, int, int, int], blur_kernel_size: int = 7) -> np.ndarray:
        """
        Blend a specific rectangular region defined by a bounding box from source image into result image.

        Args:
            result_img: Target image to blend into
            source_img: Source image for content
            bbox: Bounding box (x, y, w, h) of the region to blend
            blur_kernel_size: Kernel size for edge blending

        Returns:
            Result image with blended region
        """
        x, y, w, h = bbox
        h_img, w_img = result_img.shape[:2]

        # Ensure bbox coordinates are within image boundaries
        x = max(0, x)
        y = max(0, y)
        w = min(w, w_img - x)
        h = min(h, h_img - y)

        if w <= 0 or h <= 0: # If width or height is non-positive after clipping
            return result_img # Return original image if bbox is invalid

        # Create a rectangular mask for the bounding box
        region_mask = np.zeros((h_img, w_img), dtype=np.uint8)
        cv2.rectangle(region_mask, (x, y), (x + w, y + h), 255, -1) # Fill the rectangle

        # Apply Gaussian blur to mask edges for smooth blending
        region_mask_float = cv2.GaussianBlur(
            region_mask.astype(np.float32),
            (blur_kernel_size, blur_kernel_size), 0
        ) / 255.0

        # Convert to 3-channel mask
        region_mask_3channel = np.stack([region_mask_float] * 3, axis=2)

        # Perform blending
        result_float = result_img.astype(np.float32)
        source_float = source_img.astype(np.float32)

        blended = result_float * (1 - region_mask_3channel) + source_float * region_mask_3channel

        return blended.astype(np.uint8)


    def detect_and_replace_regions(self, large_path: str,
                                  small_path: str,
                                  num_top_regions: int = 5) -> Dict[str, Any]:
        """
        Main method to detect difference regions, group them, and replace the
        top N largest ones using the small image.

        Args:
            large_path: Path to the large image
            small_path: Path to the small image
            num_top_regions: Number of top largest regions to replace.

        Returns:
            Dictionary containing all results and metadata
        """
        try:
            # Load and validate images (only large and small)
            large_img, small_img = self.load_and_validate_images(
                large_path, small_path
            )

            # Resize small image to match large image dimensions
            large_img, small_resized = self.resize_images_to_match(
                large_img, small_img
            )

            large_h, large_w = large_img.shape[:2]
            logger.info(f"Processing images with dimensions: {large_w}x{large_h}")

            # Calculate difference mask
            mask, diff = self.calculate_difference_mask(large_img, small_resized)

            # Find all individual difference regions (contours)
            all_regions = self.find_difference_regions(mask, diff)
            logger.info(f"Found {len(all_regions)} individual difference regions")

            # Group nearby regions into single bounding boxes
            grouped_bboxes = self.group_nearby_regions(all_regions)
            logger.info(f"Grouped into {len(grouped_bboxes)} merged regions for replacement")

            # --- New Logic: Sort and select top N regions ---
            # Calculate area for each grouped bbox and store with bbox
            regions_with_areas = []
            for bbox in grouped_bboxes:
                x, y, w, h = bbox
                regions_with_areas.append({'bbox': bbox, 'area': w * h})

            # Sort regions by area in descending order
            regions_with_areas.sort(key=lambda x: x['area'], reverse=True)

            # Select the top N regions
            top_n_regions = regions_with_areas[:num_top_regions]
            logger.info(f"Selected top {len(top_n_regions)} regions out of {len(grouped_bboxes)} for replacement.")
            # --- End New Logic ---

            # Replace selected top regions with content from the small image
            result_img = large_img.copy()
            replaced_bboxes_info = []

            for i, region_info in enumerate(top_n_regions):
                bbox = region_info['bbox']
                result_img = self.blend_region_by_bbox(result_img, small_resized, bbox)
                x, y, w, h = bbox
                replaced_bboxes_info.append({
                    'bbox': bbox,
                    'area': w * h,
                    'center': (x + w//2, y + h//2)
                })
                logger.info(f"Replaced Top Region {i+1}: Bbox({x},{y},{w},{h}), Area: {w*h}")

            # Calculate statistics based on *replaced* regions
            total_replaced_area = sum(info['area'] for info in replaced_bboxes_info)
            total_image_area = large_w * large_h
            replacement_percentage = (total_replaced_area / total_image_area) * 100

            logger.info(f"Total replaced area: {total_replaced_area:.0f} pixels "
                      f"({replacement_percentage:.2f}%)")

            return {
                'large_image': large_img,
                'small_image': small_resized,
                'result_image': result_img,
                'difference_mask': mask,
                'difference_image': diff,
                'grouped_bboxes': grouped_bboxes, # Still return all grouped for info
                'top_replaced_bboxes': [r['bbox'] for r in top_n_regions], # New field
                'all_individual_regions': all_regions,
                'replaced_bboxes_info': replaced_bboxes_info, # Only includes the top N
                'replacement_percentage': replacement_percentage,
                'total_replaced_area': total_replaced_area,
                'settings': {
                    'threshold': self.threshold,
                    'min_area': self.min_area,
                    'max_grouping_distance': self.max_grouping_distance,
                    'num_top_regions_replaced': num_top_regions # New setting
                }
            }
        except Exception as e:
            logger.error(f"Error in detect_and_replace_regions: {e}")
            raise


class ImageProcessor:
    """
    Main image processing class that orchestrates various image operations.
    """

    def __init__(self, threshold: int = 20, min_area: int = 50, # Adjusted threshold and min_area
                 max_grouping_distance: int = 100): # Propagate new parameter
        """
        Initialize the image processor.

        Args:
            threshold: Threshold for region detection
            min_area: Minimum area for regions
            max_grouping_distance: Maximum pixel distance for grouping regions
        """
        self.region_detector = RegionDetector(threshold, min_area, max_grouping_distance)

    def process_listing_images(self, listing: Dict, output_dir: str) -> Dict:
        """
        Process all images for a single listing.

        Args:
            listing: Listing dictionary with downloaded image paths
            output_dir: Directory to save processed images

        Returns:
            Dictionary with processing results
        """
        processed_paths = []
        processing_log = []

        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)

        downloaded_paths = listing.get('downloaded_paths', {})
        large_images = downloaded_paths.get('large', [])
        # medium_images removed as per user request
        small_images = downloaded_paths.get('small', [])

        # Process each set of images (large, small)
        # Assuming large_images and small_images lists are aligned by index
        for i in range(len(large_images)):
            try:
                large_path = large_images[i] if i < len(large_images) else None
                small_path = small_images[i] if i < len(small_images) else None

                if not all([large_path, small_path]): # Only check large and small
                    logger.warning(f"Missing image paths for index {i}, skipping")
                    processing_log.append({
                        'image_index': i,
                        'large_path': large_path,
                        'small_path': small_path,
                        'output_path': None,
                        'error': "Missing image paths",
                        'status': 'skipped'
                    })
                    continue

                if not all([os.path.exists(p) for p in [large_path, small_path]]): # Only check large and small
                    logger.warning(f"One or more image files don't exist for index {i}, skipping")
                    processing_log.append({
                        'image_index': i,
                        'large_path': large_path,
                        'small_path': small_path,
                        'output_path': None,
                        'error': "One or more image files don't exist",
                        'status': 'skipped'
                    })
                    continue

                # Generate output filename
                listing_url = listing.get('url', 'unknown')
                listing_hash = hashlib.sha1(listing_url.encode()).hexdigest()[:10]
                output_filename = f"{listing_hash}_{i:02d}_cleaned.jpg"
                output_path = os.path.join(output_dir, output_filename)

                # Process the images (only passing large and small paths)
                logger.info(f"Processing image set {i+1} for listing")
                result = self.region_detector.detect_and_replace_regions(
                    large_path, small_path
                )

                replacement_percentage = result.get('replacement_percentage', 0)
                if replacement_percentage >= .003 or replacement_percentage <= .07:

                    # Save the processed image
                    cv2.imwrite(output_path, result['result_image'])
                    processed_paths.append(output_path)

                # Log the processing
                processing_log.append({
                    'image_index': i,
                    'large_path': large_path,
                    'small_path': small_path,
                    'output_path': output_path,
                    'replacement_percentage': result['replacement_percentage'],
                    'regions_processed': len(result['grouped_bboxes']), # Log grouped bboxes
                    'status': 'success'
                })

                logger.info(f"Successfully processed image {i+1}, saved to {output_path}")

            except Exception as e:
                logger.error(f"Error processing image set {i}: {e}")
                processing_log.append({
                    'image_index': i,
                    'large_path': large_path if 'large_path' in locals() else None,
                    'small_path': small_path if 'small_path' in locals() else None,
                    'output_path': None,
                    'error': str(e),
                    'status': 'failed'
                })

        return {
            'processed_paths': processed_paths,
            'processing_log': processing_log,
            'total_processed': len(processed_paths),
            'total_attempted': len(processing_log)
        }

    def process_multiple_listings(self, listings: List[Dict], output_dir: str) -> Dict:
        """
        Process images for multiple listings.

        Args:
            listings: List of listing dictionaries
            output_dir: Base directory for processed images

        Returns:
            Dictionary with overall processing results
        """
        all_results = []
        total_processed = 0
        total_failed = 0

        logger.info(f"Starting image processing for {len(listings)} listings")

        for i, listing in enumerate(listings):
            try:
                listing_title = listing.get('title', 'Unknown')[:50]
                logger.info(f"Processing listing {i+1}/{len(listings)}: {listing_title}")

                result = self.process_listing_images(listing, output_dir)
                all_results.append({
                    'listing_index': i,
                    'listing_url': listing.get('url'),
                    'listing_title': listing_title,
                    **result
                })

                total_processed += result['total_processed']
                total_failed += result['total_attempted'] - result['total_processed']

                # Update listing with processed paths
                listing['processed_image_paths'] = result['processed_paths']

            except Exception as e:
                logger.error(f"Error processing listing {i+1}: {e}")
                all_results.append({
                    'listing_index': i,
                    'listing_url': listing.get('url'),
                    'listing_title': listing.get('title', 'Unknown')[:50],
                    'error': str(e),
                    'status': 'failed'
                })
                total_failed += 1

        logger.info(f"Image processing completed: {total_processed} processed, {total_failed} failed")

        return {
            'results': all_results,
            'total_processed': total_processed,
            'total_failed': total_failed,
            'total_listings': len(listings)
        }
